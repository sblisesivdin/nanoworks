# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.
"""Validate and redraw the recorded Cr2O tables without a DFT engine.

Requires NumPy >=2 and Matplotlib. --cube-dir optionally points to the original
run's result directory to repeat checks of all eight density cubes.
"""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
PREFIX = 'Cr2O_mp-1206821_primitive-'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--cube-dir', type=Path)
args = parser.parse_args()


def table(suffix):
    return np.loadtxt(DATA / (PREFIX + suffix), skiprows=1)


def cube(path):
    with path.open() as stream:
        header = [next(stream) for _ in range(6)]
        natoms = int(header[2].split()[0])
        assert natoms == 3
        for _ in range(natoms):
            next(stream)
        dims = [int(header[i].split()[0]) for i in (3, 4, 5)]
        voxel = np.array([[float(t) for t in header[i].split()[1:4]] for i in (3, 4, 5)])
        assert all(n > 0 for n in dims)  # This archive uses bohr coordinates.
        values = np.fromstring(stream.read(), sep=' ').reshape(dims)
    assert np.isfinite(values).all()
    return values, abs(np.linalg.det(voxel))


bands, dos, projected = {}, {}, {}
checks = {}
state = json.loads((DATA / (PREFIX + 'BAND-GPAW-Result-State.json')).read_text())
shape, dtype, values = state['energies']['__ndarray__']
state_energies = np.array(values, dtype=dtype).reshape(shape)
assert state['reference'] == 0.0 and shape == [2, 40, 21]
for index, spin in enumerate(('Up', 'Down')):
    bands[spin] = table('BAND-GPAW-Result-Band-' + spin + '-XYYY.dat')
    long = table('BAND-GPAW-Result-Band-' + spin + '.dat')
    dos[spin] = table('DOS-GPAW-Result-DOS-' + spin + '.dat')
    pdos = table('DOS-GPAW-Result-PDOS-' + spin + '.dat')
    raw = np.loadtxt(DATA / (PREFIX + 'DOS-GPAW-Result-Raw-PDOS-Each-Atom-' + spin + '.dat'), dtype=str, skiprows=1)
    atoms = {i: raw[raw[:, 0].astype(int) == i, 2:].astype(float) for i in (1, 2, 3)}
    assert list(raw[::301, 1]) == ['Cr', 'Cr', 'O']
    assert bands[spin].shape == (40, 22) and long.shape == (840, 2)
    assert dos[spin].shape == (301, 2) and pdos.shape == (301, 14)
    assert np.array_equal(bands[spin][:, 1:], long[:, 1].reshape(21, 40).T)
    assert np.array_equal(bands[spin][:, 1:], state_energies[index])
    assert np.array_equal(long[:, 0], np.tile(np.arange(40), 21))
    for a in (dos[spin], pdos, *atoms.values()):
        assert np.isfinite(a).all() and np.all(a[:, 1:] >= 0)
        assert np.array_equal(a[:, 0], dos[spin][:, 0])
    for a in (*atoms.values(), pdos):
        assert np.allclose(a[:, 2], a[:, 3:6].sum(axis=1), atol=1e-12, rtol=0)
        assert np.allclose(a[:, 6], a[:, 7:12].sum(axis=1), atol=1e-12, rtol=0)
        assert np.allclose(a[:, -1], a[:, [1, 2, 6, 12]].sum(axis=1), atol=1e-12, rtol=0)
    assert np.allclose(sum(a[:, 1:] for a in atoms.values()), pdos[:, 1:], atol=1e-12, rtol=0)
    projected[spin] = {'Cr d': atoms[1][:, 6] + atoms[2][:, 6],
                       'Cr s': atoms[1][:, 1] + atoms[2][:, 1],
                       'O p': atoms[3][:, 2], 'O s': atoms[3][:, 1]}
    e = bands[spin][:, 1:]
    crossing = np.where((e.min(axis=0) < 0) & (e.max(axis=0) > 0))[0] + 1
    checks[spin] = {
        'bands_straddling_Ef_on_path_1based': crossing.tolist(),
        'DOS_at_Ef_linear_interpolation_states_per_eV_cell': float(np.interp(0, *dos[spin].T)),
        'DOS_integral_over_exported_window_states_per_cell': float(np.trapezoid(dos[spin][:, 1], dos[spin][:, 0])),
    }
kpath = np.loadtxt(DATA / (PREFIX + 'BAND-GPAW-Result-KPath.dat'), dtype=str, skiprows=1)
distance = kpath[:, 1].astype(float)
assert np.array_equal(kpath[:, 0].astype(int), np.arange(40))
assert np.all(np.diff(distance) > 0) and not np.any(kpath[:, 2].astype(int))
assert list(kpath[kpath[:, 3] != '-', 3]) == ['G', 'X', 'W', 'K', 'G']
assert np.array_equal(dos['Up'][:, 0], dos['Down'][:, 0])
checks['down_spin_sampled_path_separation_eV'] = float(bands['Down'][:, 6].min() - bands['Down'][:, 5].max())

cube_root = args.cube_dir or DATA
source_hashes = dict(line.split('  ', 1)[::-1] for line in
                     (ROOT / 'density-source-sha256.txt').read_text().splitlines())
for kind in ('npseudo', 'nall'):
    paths = [cube_root / (PREFIX + 'EDENSITY-GPAW-Result-All-electron_' + kind + '-' + t + '.cube')
             for t in ('Up', 'Down', 'Total', 'Zeta')]
    if not all(p.is_file() for p in paths):
        assert kind == 'nall' and args.cube_dir is None
        continue
    for path in paths:
        assert hashlib.sha256(path.read_bytes()).hexdigest() == source_hashes[path.name], path.name
    arrays = [cube(p) for p in paths]
    assert all(a.shape == arrays[0][0].shape and np.isclose(dv, arrays[0][1]) for a, dv in arrays)
    (up, dv), (down, _), (total, _), (zeta, _) = arrays
    ratio = np.divide(up - down, up + down, out=np.zeros_like(up), where=up + down != 0)
    # Absolute errors scale with the large core density in all-electron cubes.
    assert np.max(abs(up + down - total)) < (2e-5 if kind == 'nall' else 1e-6)
    assert np.max(abs(zeta - ratio)) < 1e-6
    checks[kind] = {'grid': list(up.shape), 'total_electrons': float(total.sum() * dv),
        'spin_moment_muB': float((up - down).sum() * dv),
        'negative_down_voxels': int((down < 0).sum()),
        'max_abs_zeta': float(abs(zeta).max())}

(ROOT / 'checks.json').write_text(json.dumps(checks, indent=2) + '\n')
plt.rcParams.update({'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False})
fig, axes = plt.subplots(1, 3, figsize=(11.5, 5.2), sharey=True,
                         gridspec_kw={'width_ratios': [1.25, 1.25, 1]})
special = kpath[:, 3] != '-'
ticks = distance[special]
labels = [r'$\Gamma$' if s == 'G' else s for s in kpath[special, 3]]
for ax, spin, color in zip(axes[:2], ('Up', 'Down'), ('#a74b2a', '#176b91')):
    for band in bands[spin][:, 1:].T:
        ax.plot(distance, band, color=color, lw=1)
    for x in ticks:
        ax.axvline(x, color='0.85', lw=.7)
    ax.set(xticks=ticks, xticklabels=labels, xlim=(distance[0], distance[-1]),
           ylim=(-5, 5), title='Spin ' + spin.lower(), xlabel='Wave-vector path')
for spin, color, sign in [('Up', '#a74b2a', 1), ('Down', '#176b91', -1)]:
    axes[2].plot(sign * dos[spin][:, 1], dos[spin][:, 0], color=color, label=spin)
axes[2].set(xlabel='DOS (states/eV/cell)', xlim=(-20, 20), title='Spin DOS')
axes[2].legend(frameon=False, fontsize=9)
axes[0].set_ylabel(r'$E-E_F$ (eV)')
for ax in axes:
    ax.axhline(0, color='0.3', ls='--', lw=.8)
axes[2].axvline(0, color='0.7', lw=.7)
fig.suptitle(r'Cr$_2$O | GPAW/PBE spin bands and tetrahedron DOS')
fig.text(.5, .015, 'Recorded fixed structure; no convergence study. Down-spin DOS is mirrored for display; raw DOS values are nonnegative.', ha='center', fontsize=9)
fig.tight_layout(rect=(0, .05, 1, .94))
fig.savefig(ROOT / 'cr2o-gpaw-spin.png', dpi=180)
plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.7), sharey=True)
for ax, spin in zip(axes, ('Up', 'Down')):
    energy = dos[spin][:, 0]
    ax.plot(energy, dos[spin][:, 1], color='0.5', lw=1, label='Total DOS')
    for label, color in zip(('Cr d', 'Cr s', 'O p', 'O s'), ('#a74b2a', '#c68c35', '#176b91', '#5b9a9a')):
        ax.plot(energy, projected[spin][label], label=label, color=color, lw=1.5)
    ax.axvline(0, color='0.3', ls='--', lw=.8)
    ax.set(xlim=(-5, 5), ylim=(0, 20), xlabel=r'$E-E_F$ (eV)', title='Spin ' + spin.lower())
axes[0].set_ylabel('States / (eV cell)')
axes[1].legend(frameon=False, fontsize=9)
fig.suptitle(r'Cr$_2$O | selected atom-projected orbital contributions')
fig.text(.5, .015, 'Cr curves sum both Cr atoms; O curves contain one O atom. Projector weights are qualitative; no smoothing added.', ha='center', fontsize=9)
fig.tight_layout(rect=(0, .05, 1, .94))
fig.savefig(ROOT / 'cr2o-gpaw-pdos.png', dpi=180)
plt.close(fig)
print(json.dumps(checks, indent=2))

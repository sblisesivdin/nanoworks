# Cr2O GPAW spin reference, 28 October 2026

Source: example-runs-Va5NDWGi/GPAW/cr2o-spin.
Nanoworks 27.2.0rc0; GPAW 26.7.0; ASE 3.29.0; 8 MPI processes.
The exact run source commit and PAW package release were not recorded.
PBE/PW 340 eV; Gamma-centred electronic grid 5x5x5; Fermi-Dirac 0.05 eV;
tetrahedron DOS with 301 energy samples; fixed three-atom structure.
No Hubbard U or SOC. One same-sign initial magnetic configuration only.

All files under data/ are original bytes: input, starting/final CIF, both-spin
band/DOS/PDOS/raw atomic PDOS tables, KPath, State JSON and four pseudo CUBEs.
SHA256SUMS covers the distributed files except itself.
The plotting script is new; no third-party source code is included.

## Reproduce figures and checks without DFT

Install numpy>=2 and matplotlib, then run:

    python plot_cr2o.py

Outputs: cr2o-gpaw-spin.png, cr2o-gpaw-pdos.png, checks.json.
The script checks band long/XYYY/State agreement, atom/orbital PDOS sums,
energy axes, finite nonnegative DOS and the included pseudo CUBE identities.
Only the displayed down DOS is mirrored. No smoothing, clipping or density
renormalization is performed.

## All-electron density evidence

density-checks.dat records the audit of all eight original density CUBEs.
The four large all-electron CUBEs are retained in the original run rather
than duplicated here. density-source-sha256.txt records all eight hashes.
If you have the original result directory, repeat the full check with:

    python plot_cr2o.py --cube-dir /path/to/Cr2O_mp-1206821_primitive

The script verifies those CUBE hashes before analyzing the arrays.
CUBE coordinates use bohr; density values use electrons/bohr^3;
Zeta is dimensionless. Integrals use the determinant of the voxel vectors.
Do not integrate Zeta to obtain the magnetic moment.

## Physical limitations

The SCF moment is 8.103239 muB/cell. No energetic magnetic ordering or relaxed
structural stability was established. Spin up crosses Ef on the sampled path.
The down-spin path has a gap but DOS is nonzero near Ef; a verified half-metal
claim would require denser full-zone and energy sampling.
The finite-window DOS integrals differ visibly from the 21 states per channel.
The coarse pseudo down density has 136 negative voxels and |Zeta|>1 there.
Its algebra is consistent but those ratios are not physical local spin
polarizations. The all-electron spin densities are nonnegative and reproduce
56 electrons and the SCF moment approximately; grid convergence remains open.

See the Nanoworks Cr2O GPAW spin tutorial for values and interpretation.
Project code and data are distributed under LICENSE.md (MIT).

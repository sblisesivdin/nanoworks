# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.

"""Check and redraw the archived Si phonons; no DFT or Phonopy required."""
from pathlib import Path
import hashlib
import numpy as np
import yaml
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
PREFIX = 'Si_mp-149_primitive-PHONON-GPAW-Result-'


def load(suffix):
    return ROOT / (PREFIX + suffix)


def main():
    manifest = ROOT / 'SHA256SUMS'
    if manifest.exists():
        for line in manifest.read_text().splitlines():
            digest, name = line.split('  ', 1)
            actual = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
            if actual != digest:
                raise ValueError('SHA256 mismatch: ' + name)
    band_yaml = yaml.safe_load(load('Band.yaml').read_text())
    phonopy = yaml.safe_load(load('Phonopy.yaml').read_text())
    band = np.loadtxt(load('Band.dat'), skiprows=1)
    dos = np.loadtxt(load('DOS.dat'), skiprows=1)
    mesh = np.loadtxt(load('Mesh-THz.dat'), skiprows=1)
    fc = np.load(load('Force-Constants.npy'), allow_pickle=False)
    forces = np.load(load('Supercell-0000.npy'), allow_pickle=False)
    reference = np.array([[q['distance']] + [b['frequency'] for b in q['band']]
                          for q in band_yaml['phonon']])
    assert band.shape == reference.shape == (244, 7)
    assert mesh.shape == (4000, 10)
    assert fc.shape == (2, 54, 3, 3) and forces.shape == (54, 3)
    for array in (band, dos, mesh, fc, forces):
        assert np.isfinite(array).all()
    band_error = float(np.max(np.abs(band - reference)))
    assert band_error < 5.1e-7
    fc_yaml = np.asarray(phonopy['force_constants']['elements']).reshape(fc.shape)
    fc_error = float(np.max(np.abs(fc - fc_yaml)))
    assert fc_error < 1e-12
    force_error = float(np.max(np.abs(
        forces - np.asarray(phonopy['displacements'][0]['forces']))))
    assert force_error < 1e-12
    asr = float(np.max(np.abs(fc.sum(axis=1))))
    assert asr < 1e-12
    assert np.all(dos[:, 1] >= 0) and np.all(np.diff(dos[:, 0]) > 0)
    assert np.all(dos[dos[:, 0] < 0, 1] == 0)
    assert np.all(mesh[:, 4:] > 0)
    assert mesh[:, 3].sum() == 20 ** 3
    assert np.all(mesh[:, 3] == 2)
    # A half-grid shifted mesh has no point equivalent to Gamma.
    gamma_distance = np.linalg.norm(mesh[:, :3] - np.rint(mesh[:, :3]), axis=1)
    assert gamma_distance.min() > 1e-6
    gamma = reference[0, 1:]
    assert np.max(np.abs(gamma[:3])) < 3e-7
    assert np.ptp(gamma[3:]) < 1e-8
    integral = float(np.trapezoid(dos[:, 1], dos[:, 0]))
    assert abs(integral - 6) < 0.02
    checks = [
        ('band_yaml_max_error', band_error, 'mixed_THz_and_1/angstrom'),
        ('fc_yaml_max_error', fc_error, 'eV/angstrom^2'),
        ('forces_yaml_max_error', force_error, 'eV/angstrom'),
        ('asr_max_residual', asr, 'eV/angstrom^2'),
        ('net_force_max_component', float(np.max(np.abs(forces.sum(axis=0)))), 'eV/angstrom'),
        ('dos_integral', integral, 'modes/primitive_cell'),
        ('mesh_minimum_frequency', float(mesh[:, 4:].min()), 'THz'),
        ('mesh_weight_sum', float(mesh[:, 3].sum()), '1'),
        ('mesh_gamma_equivalent_count', float(np.count_nonzero(gamma_distance < 1e-6)), '1'),
        ('gamma_optical_frequency', float(gamma[3]), 'THz'),
    ]
    (ROOT / 'checks.dat').write_text(
        '# quantity value unit\n' + ''.join(f'{k} {v:.14g} {u}\n' for k, v, u in checks))

    plt.rcParams.update({'font.size': 11, 'axes.spines.top': False,
                         'axes.spines.right': False, 'savefig.dpi': 180})
    fig, (ax, dx) = plt.subplots(1, 2, figsize=(10.3, 4.8),
                                 gridspec_kw={'width_ratios': [3.4, 1]}, sharey=True)
    x, frequencies = reference[:, 0], reference[:, 1:]
    for i in range(6):
        ax.plot(x, frequencies[:, i], color='#185f9c', lw=1.25, alpha=0.86)
    endpoints = np.r_[0, np.cumsum(band_yaml['segment_nqpoint']) - 1]
    for tick in x[endpoints]:
        ax.axvline(tick, color='#ccd4dc', lw=0.7, zorder=0)
    ax.axhline(0, color='#59616a', lw=0.7)
    ax.set(xticks=x[endpoints], xticklabels=[r'$\Gamma$', 'X', 'U', 'L', r'$\Gamma$'],
           xlim=(x[0], x[-1]), ylim=(-0.4, 15.8), ylabel='Frequency (THz)',
           xlabel='Wave vector along the recorded path', title='Si phonon dispersion')
    ax.text(0.02, 0.985, '2-atom primitive cell · 6 branches', transform=ax.transAxes,
            va='top', fontsize=9, color='#425466')
    dx.plot(dos[:, 1], dos[:, 0], color='#b85c26', lw=1.3)
    dx.fill_betweenx(dos[:, 0], 0, dos[:, 1], color='#e4a775', alpha=0.4)
    dx.axhline(0, color='#59616a', lw=0.7)
    dx.set(xlim=(0, None), xlabel='DOS (modes/THz\nper primitive cell)', title='Phonon DOS')
    dx.text(0.95, 0.985, f'Integral = {integral:.3f}', transform=dx.transAxes,
            ha='right', va='top', fontsize=9, color='#425466')
    fig.tight_layout()
    fig.savefig(ROOT / 'si-gpaw-phonons.png', bbox_inches='tight')
    plt.close(fig)
    for k, v, unit in checks:
        print(f'{k}: {v:.10g} {unit}')


if __name__ == '__main__':
    main()

# Recorded silicon GPAW phonons

Source: example-runs-Va5NDWGi/GPAW/si-phonon, 28 October 2026.
Tutorial: https://nanoworks.readthedocs.io/en/latest/examples/si-gpaw-phonons.html

The input and starting CIF match the bundled Si-phonon example. Nanoworks
27.2.0rc0, GPAW 26.7.0, ASE 3.29.0, Phonopy 4.8.6; eight processes.
Exact Nanoworks run commit and PAW dataset package release are unknown.
Si PBE setup id: ee77bee481871cc2cb65ac61239ccafa.

PBE/PW 500 eV; non-spin-polarized, no SOC; ground 11x11x11 Gamma-centred;
force SCFs 4x4x4 Monkhorst-Pack on 3x3x3 primitive supercells (54 atoms);
Fermi-Dirac width 0.01 eV, very-tight SCF; displacement 0.01 angstrom.
Normal strains relaxed, shear fixed, geometry tolerance 0.0001 eV/angstrom.
Acoustic sum rule applied. GXULG band path, 61 samples per segment;
20x20x20 shifted DOS mesh, time reversal only, 4000 representatives.
No thermal-property calculation was requested.

Install numpy>=2, matplotlib and PyYAML, then run:

    python plot_phonons.py

The script verifies source hashes, checks DAT versus YAML, NPY versus YAML,
force-constant sum rules, DOS normalization and mesh contents, then writes
si-gpaw-phonons.png and checks.dat. It needs neither GPAW nor Phonopy.
All input, CIF, NPY, DAT and YAML files are original bytes. SHA256SUMS covers
the source files, script, README and license; it excludes regenerated PNG
and checks.dat.

Checks establish internal consistency, not convergence. The tiny signed Gamma
acoustic frequencies are numerical residuals. The shifted mesh excludes Gamma;
its 0.362277 THz minimum is not an acoustic gap. The symmetry-fallback warning
indicates disabled point-group reduction, with time reversal retained.
No replacement DFT or alternative mesh calculation was run during review.

Electronic state/log files and absolute-path postprocessing plans are omitted.
To rerun DFT, use the installed example and current Nanoworks documentation.
The YAML retains the primitive-basis transformation and displaced forces.

# Recorded pristine/vacancy graphene spectra

Source: example-runs-Va5NDWGi, GPAW/graphene-pristine and GPAW/graphene-defect, 28 October 2026.

Use the website tutorial for the Nanoworks commands and scientific limitations. Inputs and CIFs match the inspected repository. All original electronic tables are preserved. Large densities, GPW and machine-specific logs are omitted. Separate Fermi references; unconverged DOS; constrained non-spin-polarized vacancy.

Optional redraw: install numpy>=2 and matplotlib, then run `python plot_graphene_comparison.py` here. This checks electronic export identities and writes checks.dat and the two PNGs without running DFT. checks.dat is derived; the original DAT files are under data/.

SHA256SUMS covers all distributed files except itself. MIT terms are in LICENSE.md.

# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.
"""Verify and redraw the recorded graphene spectra; no DFT calculation."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
records = {}
checks = []
for case, natoms, nbands in [('pristine', 32, 128), ('defect', 31, 124)]:
    folder = ROOT / 'data' / case
    def read(suffix):
        return np.loadtxt(next(folder.glob('*' + suffix)), skiprows=1)
    b = read('Band-XYYY.dat')
    long = read('Result-Band.dat')
    dos = read('Result-DOS.dat')
    pdos = read('Result-PDOS.dat')
    raw = np.loadtxt(next(folder.glob('*Raw-PDOS-Each-Atom.dat')), dtype=str, skiprows=1)
    atoms = np.array([raw[raw[:, 0].astype(int) == i, 2:].astype(float)
                      for i in range(1, natoms + 1)])
    assert set(raw[:, 1]) == {'C'} and atoms.shape == (natoms, 501, 14)
    assert b.shape == (40, nbands + 1) and dos.shape == (501, 2)
    assert np.array_equal(b[:, 0], np.arange(40))
    assert np.array_equal(long[:, 0], np.tile(np.arange(40), nbands))
    assert np.array_equal(long[:, 1].reshape(nbands, 40).T, b[:, 1:])
    state = json.loads(next(folder.glob('*Result-State.json')).read_text())
    shape, dtype, values = state['energies']['__ndarray__']
    assert shape == [1, 40, nbands] and state['reference'] == 0
    assert np.array_equal(np.array(values, dtype=dtype).reshape(shape)[0], b[:, 1:])
    kp = np.loadtxt(next(folder.glob('*KPath.dat')), dtype=str, skiprows=1)
    x = kp[:, 1].astype(float)
    assert np.array_equal(kp[:, 0].astype(int), np.arange(40))
    assert np.all(np.diff(x) > 0) and not np.any(kp[:, 2].astype(int))
    assert list(kp[kp[:, 3] != '-', 3]) == ['G', 'K', 'M', 'G']
    assert np.array_equal(dos[:, 0], pdos[:, 0])
    assert np.all(np.diff(dos[:, 0]) > 0)
    assert all(np.array_equal(a[:, 0], dos[:, 0]) for a in atoms)
    assert all(np.isfinite(a).all() for a in (b, long, dos, pdos, atoms))
    assert np.all(dos[:, 1] >= 0) and np.all(pdos[:, 1:] >= 0)
    assert np.all(atoms[:, :, 1:] >= 0)
    atom_error = np.max(abs(atoms[:, :, 1:].sum(0) - pdos[:, 1:]))
    assert atom_error < 1e-10
    for a in (pdos, *atoms):
        assert np.allclose(a[:, 2], a[:, 3:6].sum(1), atol=1e-10, rtol=0)
        assert np.allclose(a[:, 6], a[:, 7:12].sum(1), atol=1e-10, rtol=0)
        assert np.allclose(a[:, -1], a[:, [1, 2, 6, 12]].sum(1), atol=1e-10, rtol=0)
    crossing = np.where((b[:, 1:].min(0) < 0) & (b[:, 1:].max(0) > 0))[0] + 1
    occupied = 2 * natoms
    separation = b[:, occupied + 1].min() - b[:, occupied].max()
    checks.extend([
        f'{case} DOS_window_integral(states/cell) {np.trapezoid(dos[:,1], dos[:,0]):.12g}',
        f'{case} full_band_weight(states/cell) {2*nbands}',
        f'{case} DOS_at_Ef_interpolated(states/eV/cell) {np.interp(0,*dos.T):.12g}',
        f'{case} occupied_index_path_separation(eV) {separation:.12g}',
        f'{case} atom_sum_max_error(states/eV/cell) {atom_error:.12g}',
        f'{case} bands_straddling_Ef_1based(1) ' + ','.join(map(str, crossing)),
    ])
    records[case] = dict(b=b[:, 1:], dos=dos, pdos=pdos, kp=kp, x=x, natoms=natoms)

colors = {'pristine': '#176b91', 'defect': '#b35b29'}
plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
fig, axes = plt.subplots(1, 3, figsize=(11.5, 5), sharey=True,
                         gridspec_kw={'width_ratios': [1.2, 1.2, 1]})
for ax, (case, r) in zip(axes[:2], records.items()):
    for band in r['b'].T:
        ax.plot(r['x'], band, lw=.8, color=colors[case])
    ticks = r['x'][r['kp'][:, 3] != '-']
    for tick in ticks:
        ax.axvline(tick, color='.85', lw=.6)
    ax.set(xticks=ticks, xticklabels=[r'$\Gamma$', 'K', 'M', r'$\Gamma$'],
           xlim=(0, r['x'][-1]), ylim=(-2, 2), xlabel='Supercell path',
           title=f'{case.capitalize()} ({r["natoms"]} C)')
for case, r in records.items():
    axes[2].plot(r['dos'][:,1]/r['natoms'], r['dos'][:,0],
                 color=colors[case], label=case.capitalize())
axes[2].set(xlabel='DOS (states/eV/atom)', title='Tetrahedron DOS')
axes[2].legend(frameon=False)
axes[0].set_ylabel(r'$E-E_F$ of each calculation (eV)')
for ax in axes:
    ax.axhline(0, ls='--', color='.3', lw=.7)
fig.suptitle('Pristine graphene and a neutral vacancy | recorded LDA/LCAO results')
fig.text(.5, .02, 'Separate Fermi zeros; folded supercell bands; coarse DOS samples, no added smoothing.', ha='center', fontsize=9)
fig.tight_layout(rect=(0,.05,1,.94))
fig.savefig(ROOT/'graphene-gpaw-vacancy.png', dpi=180)
plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.8))
r = records['pristine']
for j in (63,64):
    axes[0].plot(r['x'][14:19]-r['x'][16], r['b'][14:19,j]*1000,
                 marker='o', label=f'Band {j+1}')
axes[0].axvline(0, color='.6', ls=':')
axes[0].axhline(0, color='.6', ls=':')
axes[0].set(xlabel=r'Path distance from K ($\mathrm{\AA}^{-1}$)',
            ylabel=r'$E-E_F$ (meV)', title='Pristine: recorded samples near K')
axes[0].legend(frameon=False)
axes[0].annotate('K separation: 0.587 meV', (0,3), xytext=(.02,40),
                 arrowprops={'arrowstyle':'->'}, fontsize=9)
for case,r in records.items():
    p=r['pdos']/r['natoms']
    axes[1].plot(r['pdos'][:,0],p[:,3], color=colors[case], label=case.capitalize()+r' $p_z$')
    axes[1].plot(r['pdos'][:,0],p[:,4]+p[:,5], color=colors[case], ls='--',
                 label=case.capitalize()+r' $p_x+p_y$')
axes[1].set(xlim=(-1,1), xlabel=r'$E-E_F$ of each calculation (eV)',
            ylabel='Projected states / (eV atom)', title='Carbon orbital projections')
axes[1].axvline(0, color='.6', ls=':')
axes[1].legend(frameon=False, fontsize=8)
fig.text(.5,.02,'Lines connect saved samples; residual K splitting is not a converged material gap. Projectors do not partition total DOS.', ha='center', fontsize=8)
fig.tight_layout(rect=(0,.05,1,1))
fig.savefig(ROOT/'graphene-gpaw-vacancy-checks.png', dpi=180)
plt.close(fig)
(ROOT/'checks.dat').write_text('# Recorded spectral checks; separate Fermi references.\n'+'\n'.join(checks)+'\n')
print('\n'.join(checks))

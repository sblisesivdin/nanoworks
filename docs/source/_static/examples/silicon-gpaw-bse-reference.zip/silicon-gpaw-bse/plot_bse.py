# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.

"""Verify and redraw archived Si BSE spectra and weighted eigenvalues."""
from pathlib import Path
import hashlib
import re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
PREFIX = 'Si_mp-149_primitive_Example-OPTICAL-GPAW-'
HBAR = 6.582119569e-16  # eV s
C = 2.99792458e10  # cm/s
# ASE constants used in the archived GPAW calculation.
BOHR = 0.5291772105638411  # angstrom
HARTREE = 27.211386024367243  # eV
VOLUME = 40.888292745103335  # angstrom^3 per two-atom primitive cell


def source(case, suffix):
    return ROOT / case / (PREFIX + suffix)


def table(case):
    return np.loadtxt(source(case, 'Result-Calculation-BSE-AllData.dat'), skiprows=1)


def poles(case):
    return np.loadtxt(source(case, 'Result-Calculation-BSE_eig.dat'))


def main():
    manifest = ROOT / 'SHA256SUMS'
    if manifest.exists():
        for line in manifest.read_text().splitlines():
            digest, name = line.split('  ', 1)
            if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest:
                raise ValueError('Source hash mismatch: ' + name)
    checks = []
    for case, nq, count, end in [('staged', 64, 1001, 20.), ('combined', 8, 101, 10.)]:
        a = table(case)
        raw = np.loadtxt(source(case, 'Result-Calculation-BSE_dielec.csv'), delimiter=',')
        eig = poles(case)
        log = source(case, 'Log-Calculation-BSE.txt').read_text()
        assert a.shape == (count, 7) and eig.shape == (nq*4*4, 3)
        for values in (a, raw, eig): assert np.isfinite(values).all()
        assert np.array_equal(a[:, :3], raw)
        np.testing.assert_allclose(a[:, 0], np.linspace(0, end, count), atol=1e-12)
        assert np.array_equal(eig[:, 0], np.arange(len(eig)))
        assert np.all(np.diff(eig[:, 1]) >= 0) and np.all(eig[:, 1] > 0)
        assert np.all(eig[:, 2] >= 0)
        assert 'Tamm-Dancoff approximation     : True' in log
        assert 'Eliminated 0 pair orbitals' in log
        assert 'Calculation completed at:' in log
        E, e1, e2, n, k, alpha, reflection = a.T
        assert np.all(a[:, 2:6] >= 0)
        assert np.all((reflection >= 0) & (reflection <= 1))
        np.testing.assert_allclose(n*n-k*k, e1, rtol=3e-10, atol=4e-9)
        np.testing.assert_allclose(2*n*k, e2, rtol=3e-10, atol=4e-9)
        np.testing.assert_allclose(alpha, 2*E*k/(HBAR*C), rtol=3e-11, atol=1e-8)
        np.testing.assert_allclose(reflection,
            ((n-1)**2+k*k)/((n+1)**2+k*k), rtol=3e-10, atol=3e-12)
        # Electron-equivalent f-sum diagnostic, integrating only the saved window.
        fsum = VOLUME/BOHR**3/(2*np.pi**2*HARTREE**2)*np.trapezoid(E*e2, E)
        logged_integral = float(re.search(r'Frequency integral:\s*([\d.]+)', log)[1])
        logged_weight_sum = float(re.search(r'Sum of weights\s*:\s*([\d.]+)', log)[1])
        assert abs(fsum-logged_integral) < 1.1e-6
        peak = int(np.argmax(e2))
        values = [
            ('pair_count', len(eig), '1'),
            ('minimum_eigenvalue', eig[0, 1], 'eV'),
            ('maximum_epsilon2_energy', E[peak], 'eV'),
            ('maximum_epsilon2', e2[peak], '1'),
            ('epsilon2_at_zero', e2[0], '1'),
            ('frequency_integral_electron_equivalent', fsum, 'electron/cell'),
            ('logged_weight_sum', logged_weight_sum, 'electron/cell'),
            ('frequency_integral_relative_error', fsum/8-1, '1'),
        ]
        checks.extend((case+'_'+name, value, unit) for name, value, unit in values)
    (ROOT/'checks.dat').write_text('# quantity value unit\n'+
        ''.join(f'{name} {value:.14g} {unit}\n' for name, value, unit in checks))

    plt.rcParams.update({'font.size': 10.5, 'axes.spines.top': False,
                         'axes.spines.right': False, 'savefig.dpi': 180})
    colours = {'staged': '#246ca6', 'combined': '#c1682b'}
    fig, axes = plt.subplots(2, 2, figsize=(10, 7.2), sharex=True)
    for i, case in enumerate(['staged', 'combined']):
        a = table(case)
        for j in [0, 1]:
            ax = axes[i, j]
            ax.plot(a[:, 0], a[:, j+1], color=colours[case], lw=1.35)
            ax.set(xlim=(0, 8), ylabel=r'$\epsilon_'+str(j+1)+'$ (dimensionless)')
            ax.axhline(0, color='#a1aab4', lw=0.6)
            title = 'Staged: 4³ grid, 100 eV response cutoff, η = 0.05 eV' if case=='staged' else \
                    'Combined smoke: 2³ grid, 50 eV response cutoff, η = 0.10 eV'
            ax.set_title(title, fontsize=9)
        axes[i, 1].set_ylim(bottom=0)
    for ax in axes[-1]: ax.set_xlabel('Photon energy (eV)')
    fig.tight_layout()
    fig.savefig(ROOT/'silicon-gpaw-bse.png', bbox_inches='tight')
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(10.2, 3.8), sharey=True)
    for ax, case in zip(axes, ['staged', 'combined']):
        eig = poles(case)
        relative = eig[:, 2]/eig[:, 2].max()
        ax.vlines(eig[:, 1], 0, relative, colors=colours[case], lw=1, alpha=0.8)
        ax.set(xlim=(0, 8), ylim=(0, 1.08), xlabel='BSE eigenvalue (eV)',
               title=f'{case.capitalize()}: {len(eig)} recorded eigenpairs')
        ax.axvline(eig[0, 1], color='#777777', ls='--', lw=0.8)
        ax.text(0.97, 0.94, f'Lowest pole: {eig[0, 1]:.6f} eV',
                transform=ax.transAxes, ha='right', va='top', fontsize=9)
    axes[0].set_ylabel('Relative archived spectral weight')
    fig.tight_layout()
    fig.savefig(ROOT/'silicon-gpaw-bse-poles.png', bbox_inches='tight')
    plt.close(fig)
    print('CSV/DAT identities, eigenpair counts, optical identities and logged f-sum integrals passed.')
    for name, value, unit in checks: print(f'{name}: {value:.10g} {unit}')


if __name__ == '__main__':
    main()

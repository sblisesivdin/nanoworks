# Recorded silicon GPAW BSE examples

Source: example-runs-Va5NDWGi/GPAW/silicon-optical-stages and
GPAW/silicon-combined-bse, 28 October 2026.
Tutorial: https://nanoworks.readthedocs.io/en/latest/examples/silicon-gpaw-bse.html

Nanoworks 27.2.0rc0, GPAW 26.7.0, ASE 3.29.0, eight processes.
Exact run commit and PAW dataset package release were not recorded.
Si PBE setup id: ee77bee481871cc2cb65ac61239ccafa.

Both calculations use the same fixed two-atom bulk Si cell, PBE, spin/SOC off,
Fermi-Dirac width 0.05 eV, eight screening/optical bands, valence 0..3 and
conduction 4..7, Tamm-Dancoff approximation and zero scissors correction.
Staged: PW 340 eV, Gamma 4x4x4 grid, response cutoff 100 eV,
eta 0.05 eV, 0-20 eV in 1001 points; 1024 pair states/eigenpairs.
Combined smoke: PW 250 eV, Gamma 2x2x2 grid, response cutoff 50 eV,
eta 0.1 eV, 0-10 eV in 101 points; 128 pair states/eigenpairs.
Several parameters differ simultaneously; this is not a controlled test
of staged versus combined execution or a converged Si benchmark.

With NumPy 2 or newer and Matplotlib installed:

    python plot_bse.py

The script verifies SHA256SUMS, raw/processed optical spectra, eigenpair
counts, optical identities and independently reproduces the logged
frequency-integral f-sum diagnostics. It writes checks.dat and two figures.
It imports no GPAW and launches no calculations. The original inputs,
CIFs, DATs, CSVs and method-specific BSE logs retain their original bytes.
The source hash manifest excludes regenerated PNGs and checks.dat.

DAT optical columns: energy (eV), epsilon1, epsilon2, n, kappa,
absorption coefficient (1/cm), reflectivity (fraction).
Raw BSE CSVs have no header: energy (eV), epsilon1, epsilon2.
Eigenvalue DAT: index, energy (eV), raw GPAW weight in the archived convention.
These weights are not probabilities. The pole figure divides each weight
by the maximum weight in that case only for display; the dielectric figure
uses the original amplitudes. Neither figure shows the full high-energy range.

The f-sum script uses the verified cell volume 40.888292745103335 angstrom^3,
ASE Bohr/Hartree constants, and N_eff = V/(2*pi^2) integral(omega*epsilon2)
in atomic units over only the saved frequency window. This gives
7.210555 (staged) and 10.650007 (combined), compared to target 8 electrons.
The separate log weight sums are 7.190621 and 10.864520. These discrepancies
remain visible; no spectrum is rescaled to force agreement.

The lowest BSE eigenvalue is not by itself an exciton binding energy.
A broadened spectrum maximum differs from a discrete eigenvalue. No GW
energies, converged continuum reference or eigenvectors are supplied here;
spatial exciton localization is not determined. Nonzero epsilon2 at E=0
in the archived broadened spectra is not a measured dc response.

The staged folder was previously used for RPA; its shared optical summary
now refers to BSE. These method-specific BSE files were checked against
both their log and the BSE completion summary's DAT hash during review.
Electronic states, general machine-specific logs and summaries are omitted.

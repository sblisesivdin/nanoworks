# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.

from ase.build import mx2

Outdirname = 'WSe2-wo-SOC'

bulk_configuration = mx2(formula='WSe2', kind='2H', a=3.28, thickness=3.14, size=(1, 1, 1), vacuum=15)

# -------------------------------------------------------------
Mode = 'PW'             # Use PW, PW-GW, LCAO, FD  (PW is more accurate, LCAO is quicker mostly.)
# -------------------------------------------------------------
Ground_calc = True     # Ground state calculations
Geo_optim = False       # Geometric optimization with LFBGS
Elastic_calc = False    # Elastic calculation
DOS_calc = True         # DOS calculation
Band_calc = True        # Band structure calculation
Density_calc = False    # Calculate the all-electron density?
Optical_calc = False     # Calculate the optical properties
SOC_calc = False              # Calculate Spin Orbit Coupling Effects
# -------------------------------------------------------------
# Parameters
# -------------------------------------------------------------
# GEOMETRY
Geometry_optimizer = 'LBFGS'      # QuasiNewton, GPMin, LBFGS or FIRE
Geometry_force_tolerance = 0.05 	 # Maximum force tolerance in LBFGS geometry optimization. Unit is eV/Ang.
Geometry_max_step = 0.2    # How far is a single atom allowed to move. Default is 0.2 Ang.
Fix_symmetry = True    # True for preserving the spacegroup symmetry during optimisation
# Which components of strain will be relaxed: EpsX, EpsY, EpsZ, ShearYZ, ShearXZ, ShearXY
# Example: For a x-y 2D nanosheet only first 2 component will be true
Relax_cell=[True, True, True, False, False, False]
Hydrostatic_pressure=0.0 #GPa

# ELECTRONIC
Wavefunction_cutoff = 400 	# eV
Ground_kpts_x = 9 	        # kpoints in x direction
Ground_kpts_y = 9	 	# kpoints in y direction
Ground_kpts_z = 1		# kpoints in z direction
Gamma = True
Band_path = 'GMKG'	    # Brillouin zone high symmetry points
Band_npoints = 100		# Number of points between high symmetry points
Hubbard_U = {}            # Can be used like {'N-2p': 6.0}, for none use {}

XC_calc = 'PBE'         # Exchange-Correlation, choose one: LDA, PBE, GLLBSCM, HSE06, HSE03, revPBE, RPBE, PBE0, EXX, B3LYP

SCF_accuracy = 'normal'  # Portable across GPAW and QE
Occupation_scheme = 'fermi-dirac'
Smearing_width = 0.05

DOS_npoints = 501        # Number of points
DOS_integration = 'smearing'
DOS_width = 0.1          # Gaussian DOS broadening in eV

Spin_calc = False        # Spin polarized calculation?
Magmom_per_atom = 1.0    # Magnetic moment per atom
Refine_grid = 4             # refine grid for all electron density (1, 2 [=default] and 4)
Total_charge = 0.0       # Total charge. Normally 0.0 for a neutral system.

#GENERAL
Energy_min = -5 		# eV. It is the minimum energy value for band structure and DOS figures.
Energy_max = 5  		# eV. It is the maximum energy value for band structure and DOS figures.
# Localization = "tr_TR" # Localization setting for figures. en_UK is default.

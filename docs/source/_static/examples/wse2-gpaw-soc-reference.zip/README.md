# WSe2 GPAW SOC comparison

The no-soc/ and soc/ folders preserve original input, CIF, band-state JSON,
long/XYYY/KPath DATs and recorded DOS data. No original data are overwritten.
provenance.json records the run metadata; LOG-SHA256SUMS identifies inspected
logs without redistributing machine-specific paths. Large GPWs are excluded.

Run `python plot_wse2.py` with NumPy, Matplotlib and ASE. It verifies source
hashes, geometry/settings, band representations and k-point path, K splittings,
path gaps and non-SOC PDOS sums, then redraws two PNGs and checks.dat.
SOURCE-SHA256SUMS covers original files; SHA256SUMS covers all package files
except itself. LICENSE.md contains the project license.

Band energies are already E - Ef, with State reference zero. The relevant
reference is each run's scalar-state Fermi level, not a vacuum alignment or an
independently recomputed SOC chemical potential. Scalar band count 26 is
spin-degenerate; SOC has 52 spinors. There are 26 electrons per cell.
K is index56, M36, Gamma0/99. K valence splitting0.501189296451eV, conduction
splitting0.018544075796eV. Sampled path gaps:1.384616309876eV (Gamma-K) without
SOC,1.129245506618eV (K-K) with SOC. These do not establish the full-BZ global
gap or an optical excitation energy. Geometry is fixed, not optimized.

IMPORTANT: the historical SOC DOS normalization is UNVALIDATED. GPAW26.7 source
has a full-BZ eigenvalue versus rank-local weight mismatch under MPI.
source-audit.json identifies the exact downloaded distribution/source hashes
and an independent synthetic reproduction with its original DOSCalculator.
Current Nanoworks checks/restores full uniform weights before evaluating SOC
DOS. The original spectrum is not repairable by an overall scale factor:
omitted k-point contributions change its shape too. This archive therefore
does not contain a corrected WSe2 SOC DOS. The second figure shows original
amplitudes on separate axes with that limitation explicitly marked.

Scalar DOS spans -74.33815 to10.64777eV with501points; SOC spans-5 to5eV with
501points. Energy sampling differs despite equal counts. Scalar full-window
integral51.1955 is not an exact52-state test: finite bounds and coarse sampling
matter. SOC restricted-window integral2.78785 is not by itself a state-count
proof. DOS and PDOS should be validated on a converged common energy grid
before quantitative comparisons. GPAW SOC PDOS is not exported here.

Inputs use mx2(..., vacuum=15) and pbc=[True,True,False]. CIF readers normally
return all pbc=True; use the Python input for reproducing boundary flags.
The source SOC timing file lacks a DOS duration. Do not infer a complete runtime
by adding its two recorded stages. QE calculations require a separate audit.

# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.

"""Check and redraw the recorded WSe2 comparison using NumPy/ASE/Matplotlib."""
import ast
import hashlib
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from ase.build import mx2
from ase.io import read
from ase.spectrum.band_structure import BandStructure

ROOT = Path(__file__).resolve().parent


def table(case, pattern, **kwargs):
    return np.loadtxt(next((ROOT / case).glob(pattern)), skiprows=1, **kwargs)


def assignments(path):
    return {node.targets[0].id: ast.dump(node.value)
            for node in ast.parse(path.read_text()).body if isinstance(node, ast.Assign)}


def main():
    for line in (ROOT / 'SOURCE-SHA256SUMS').read_text().splitlines():
        expected, name = line.split('  ', 1)
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    inputs = [assignments(next((ROOT / case).glob('*.py'))) for case in ['no-soc', 'soc']]
    assert {name for name in inputs[0] if inputs[0][name] != inputs[1][name]} == {'SOC_calc', 'Outdirname'}
    expected_geometry = mx2(formula='WSe2', kind='2H', a=3.28, thickness=3.14, vacuum=15)
    bands, paths, spectra, checks = {}, {}, {}, []
    for case, occupied in [('no-soc', 13), ('soc', 26)]:
        p = ROOT / case
        bs = BandStructure.read(next(p.glob('*State.json')))
        values = table(case, '*XYYY.dat')
        long = table(case, '*Result-Band.dat')
        e = values[:, 1:]
        assert e.shape == (100, 2 * occupied)
        assert bs.reference == 0
        np.testing.assert_allclose(e, bs.energies[0], atol=1e-12, rtol=0)
        np.testing.assert_allclose(long[:, 1].reshape(-1, 100).T, e, atol=1e-12, rtol=0)
        np.testing.assert_array_equal(long[:, 0].reshape(-1, 100), np.tile(values[:, 0], (e.shape[1], 1)))
        geometry = read(next(p.glob('*Final.cif')))
        np.testing.assert_allclose(geometry.cell, expected_geometry.cell, atol=1e-12, rtol=0)
        np.testing.assert_allclose(geometry.positions, expected_geometry.positions, atol=1e-12, rtol=0)
        kp = table(case, '*KPath.dat', usecols=[0, 1, 2])
        distance, special, labels = bs.path.get_linear_kpoint_axis()
        np.testing.assert_allclose(kp[:, 1], distance, atol=1e-12, rtol=0)
        np.testing.assert_array_equal(kp[:, 2], 0)
        assert labels == ['G', 'M', 'K', 'G']
        np.testing.assert_allclose(bs.path.kpts[[0, 36, 56, 99]],
                                   [[0, 0, 0], [.5, 0, 0], [1/3, 1/3, 0], [0, 0, 0]], atol=1e-12)
        valence, conduction = e[:, occupied - 1], e[:, occupied]
        gap = conduction.min() - valence.max()
        direct = np.min(conduction - valence)
        checks += [f'{case}_path_gap_eV {gap:.12f}', f'{case}_minimum_direct_gap_eV {direct:.12f}',
                   f'{case}_vbm_index {np.argmax(valence)}', f'{case}_cbm_index {np.argmin(conduction)}']
        np.testing.assert_allclose(gap, 1.3846163098764555 if case == 'no-soc' else 1.1292455066183884, atol=1e-10)
        dos = table(case, '*Result-DOS*.dat')
        assert dos.shape == (501, 2) and np.isfinite(dos).all()
        assert (np.diff(dos[:, 0]) > 0).all() and (dos[:, 1] >= 0).all()
        checks += [f'{case}_stored_DOS_integral {np.trapezoid(dos[:, 1], dos[:, 0]):.12f}']
        bands[case], paths[case], spectra[case] = e, (distance, special, bs.path.kpts), dos
    np.testing.assert_allclose(paths['no-soc'][2], paths['soc'][2], atol=1e-12, rtol=0)
    scalar, soc = bands['no-soc'], bands['soc']
    splitting_v = soc[56, 25] - soc[56, 24]
    splitting_c = soc[56, 27] - soc[56, 26]
    np.testing.assert_allclose([splitting_v, splitting_c], [.5011892964512521, .018544075795865922], atol=1e-12)
    pd = table('no-soc', '*Result-PDOS.dat')
    raw = table('no-soc', '*Raw-PDOS*', usecols=[0, *range(2, 16)])
    for left, right in [(pd[:, 2], pd[:, 3:6].sum(1)), (pd[:, 6], pd[:, 7:12].sum(1)),
                        (pd[:, -1], pd[:, [1, 2, 6, 12]].sum(1)),
                        (pd[:, 1:], raw[:, 1:].reshape(3, 501, 14).sum(0)[:, 1:])]:
        np.testing.assert_allclose(left, right, atol=1e-13, rtol=0)
    checks += [f'K_valence_splitting_eV {splitting_v:.12f}', f'K_conduction_splitting_eV {splitting_c:.12f}',
               'SOC_DOS_absolute_normalization UNVALIDATED_MPI_WEIGHT_DEFECT',
               'SOC_DOS_repaired_or_rescaled NO', 'checks PASS']
    (ROOT / 'checks.dat').write_text('\n'.join(checks) + '\n')

    x, special, _ = paths['no-soc']
    fig, axes = plt.subplots(1, 3, figsize=(11, 4.5), width_ratios=[1.7, 1, 1], constrained_layout=True)
    gray, orange = '#62717d', '#bb4d21'
    axes[0].plot(x, scalar, color=gray, ls='--', lw=.8, alpha=.8)
    axes[0].plot(x, soc, color=orange, lw=.65, alpha=.85)
    axes[0].set(ylim=(-3, 3.2), xlim=(x[0], x[-1]), ylabel='Energy relative to scalar-reference Ef (eV)',
                xticks=special, xticklabels=['Γ', 'M', 'K', 'Γ'], title='Recorded PBE bands')
    axes[0].legend(handles=[Line2D([], [], color=gray, ls='--', label='SOC off (spin-degenerate)'),
                            Line2D([], [], color=orange, label='SOC on (spinors)')], fontsize=8, loc='upper right')
    for ax, columns, scalar_column, limits, title in [
            (axes[1], [24, 25], 12, (-1.08, -.40), 'K valence splitting'),
            (axes[2], [26, 27], 13, (.62, .72), 'K conduction splitting')]:
        ax.plot(x, scalar[:, scalar_column], color=gray, ls='--', lw=1.3)
        ax.plot(x, soc[:, columns], color=orange, lw=1.3)
        ax.set(xlim=(x[56]-.14, x[56]+.14), ylim=limits, xticks=[x[56]], xticklabels=['K'], title=title)
        ax.axvline(x[56], color='black', alpha=.2, lw=.8)
        bottom, top = soc[56, columns]
        ax.annotate('', xy=(x[56]+.025, top), xytext=(x[56]+.025, bottom),
                    arrowprops={'arrowstyle': '<->', 'color': '#234e70'})
        label = f'{splitting_v*1000:.1f} meV' if scalar_column == 12 else f'{splitting_c*1000:.2f} meV'
        ax.text(.04, .94, label, transform=ax.transAxes, va='top', color='#234e70')
    for ax in axes:
        ax.grid(alpha=.15)
    fig.savefig(ROOT / 'wse2-gpaw-soc-bands.png', dpi=170)

    fig, axes = plt.subplots(2, 1, figsize=(8.3, 6), constrained_layout=True)
    for ax, case, color in zip(axes, ['no-soc', 'soc'], [gray, orange]):
        dos = spectra[case]
        ax.plot(dos[:, 0], dos[:, 1], color=color, marker='.' if case == 'no-soc' else None, ms=3)
        ax.set(xlim=(-5, 5), ylim=(0, 1.12 * dos[(dos[:, 0] >= -5) & (dos[:, 0] <= 5), 1].max()),
               ylabel='Recorded DOS\n(reported states/eV/cell)')
        ax.grid(alpha=.15)
    axes[0].set_title('SOC off: stored step ≈ 0.170 eV, Gaussian width 0.1 eV')
    axes[1].set_title('Historical SOC DOS: MPI weights unvalidated; no quantitative comparison', fontsize=10, color=orange)
    axes[1].set_xlabel('Energy relative to scalar-reference Ef (eV)')
    axes[1].text(.02, .92, 'Original amplitudes; not rescaled or repaired', transform=axes[1].transAxes, fontsize=9)
    fig.savefig(ROOT / 'wse2-gpaw-soc-dos-audit.png', dpi=170)
    print('\n'.join(checks))


if __name__ == '__main__':
    main()

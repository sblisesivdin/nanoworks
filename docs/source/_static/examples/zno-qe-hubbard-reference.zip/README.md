# Recorded QE ZnO audit

Run `python plot_zno_qe.py` with NumPy, Matplotlib and ASE. No QE runtime
is required. It checks the stored data and regenerates two figures,
`derived-audit.json` and `checks.dat`. SHA256SUMS records all packaged files;
SOURCE-SHA256SUMS covers byte-preserved source inputs/CIFs/tables.

## Scientific limits

The shared Hubbard geometry is invalid: its final rebuilt-basis SCF violates
the force tolerance (0.612397 > 0.05 eV/angstrom), pressure is -8747.477 GPa
and the energy jumps +606.88444 eV. Historical wrapper SUCCESS is retained
as provenance, not physical validation. Its spectra are not plotted.
The reference and native-Hubbard spectra are illustrative, use different
cells/cutoffs/meshes and cannot isolate U. No convergence certificate or
optical/full-BZ gap is provided. Native Hubbard is fixed-cell.

Band and DOS exports use distinct stage references, recorded in
recorded-metadata.json. The script aligns absolute energies before VBM
shifting. Total DOS has 501 rows, PDOS 502; actual grids are retained.
Source atom LDOS/component sums reproduce processed PDOS; separately
printed totals have rounding differences. Integrals cover limited windows,
not the full 52-electron occupied manifold.

## Provenance

Recorded on 2026-10-28, Nanoworks 27.2.0rc0 / QE 7.4.1, 8 MPI ranks.
Exact source commit and UPF bytes are not archived. Reported UPF MD5
identifiers are included in metadata, not independently verified.

- reference: https://drive.google.com/drive/folders/1tx4OyK3xtJCtdJkm1JzOuJbcBpwcZ0E7
- hubbard: https://drive.google.com/drive/folders/1qzYsG09R9f5aG-FTFuyKbxIZFqcP0FA5
- native: https://drive.google.com/drive/folders/1lr7v8Ggj0G7Jq18dJuP8X2k-CPfGKCMw

Python inputs, CIFs, DATs and atom PDOS files retain source bytes.
Sanitized QE input copies replace only path fields; no original machine
paths, raw logs, full XML, UPF or wavefunction files are distributed.
Metadata contains numerical eigenvalues/k points and relaxation traces
extracted from original XML/logs, with source hashes.
LOG-INPUT-XML-SHA256SUMS records excluded original inputs/XML/logs.
`--log-dir /path/to/original-tree` verifies these if the original
reference/hubbard/native download tree is available.
The final metadata trace entry is the final SCF basis recheck for both
relaxed cases; energy is converted with the recorded Nanoworks Ry constant.
Printed volumes/pressures retain their limited log precision.

Audit implementation: local code commit 0bee426 adds a separate final-force
check before accepting a QE relaxed structure. This is a force guard, not
a general stress or cutoff-convergence validator.

MIT licensing is retained in LICENSE.md and the script headers.

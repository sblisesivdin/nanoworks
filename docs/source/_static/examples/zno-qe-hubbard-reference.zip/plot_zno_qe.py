#!/usr/bin/env python3
# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md for license terms.
"""Audit stored QE ZnO tables and regenerate figures; no QE runtime needed."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ase.io import read

ROOT = Path(__file__).resolve().parent

def hashes(path, base):
    for line in path.read_text().splitlines():
        expected, name = line.split('  ', 1)
        assert hashlib.sha256((base / name).read_bytes()).hexdigest() == expected, name

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--log-dir', type=Path, help='Original reference/hubbard/native download tree')
    args = parser.parse_args()
    hashes(ROOT / 'SOURCE-SHA256SUMS', ROOT)
    if args.log_dir:
        hashes(ROOT / 'LOG-INPUT-XML-SHA256SUMS', args.log_dir)
    meta = json.loads((ROOT / 'recorded-metadata.json').read_text())
    data, summary = {}, {}
    for case, m in meta.items():
        folder = ROOT / case
        def file(pattern):
            found = list(folder.glob(pattern))
            assert len(found) == 1, (case, pattern, found)
            return found[0]
        def table(pattern):
            return np.loadtxt(file(pattern), skiprows=1)
        bands = table('*Band-XYYY.dat')[:, 1:]
        long = table('*-Band.dat')
        assert np.array_equal(long[:, 1].reshape(bands.shape[1], 40).T, bands)
        assert bands.shape == (40, 40 if case == 'native' else 31)
        assert np.max(np.abs(bands + m['band_reference_eV'] - np.array(m['band_eigenvalues_absolute_eV']))) < 5.1e-5
        assert abs(m['XML_fermi_eV'] - m['dos_reference_eV']) < 5.1e-5
        path = file('*KPath.dat').read_text().splitlines()[1:]
        path = [line.split() for line in path]
        x = np.array([float(row[1]) for row in path])
        ticks = [i for i, row in enumerate(path) if row[3] != '-']
        assert ticks == [0, 6, 9, 15, 18, 26, 29, 39]
        atoms = read(file('*.cif'))
        k = np.array(m['band_kpoints_crystal'])
        distance = np.r_[0., np.cumsum(np.linalg.norm(np.diff(k, axis=0) @ (2*np.pi*atoms.cell.reciprocal()), axis=1))]
        assert np.allclose(x, distance, atol=2e-6)
        dos = table('*-Result-DOS.dat')
        raw = np.loadtxt(file('*-Raw-DOS.dat'))
        pdos = table('*-Result-PDOS.dat')
        raw_total = np.loadtxt(file('*.pdos_tot'))
        assert dos.shape[0] == 501 and pdos.shape == (502, 14)
        assert np.allclose(dos[:, 0], raw[:, 0] - m['dos_reference_eV'], atol=1e-10)
        assert np.array_equal(dos[:, 1], raw[:, 1])
        assert np.allclose(pdos[:, 0], raw_total[:, 0] - m['dos_reference_eV'], atol=1e-10)
        summed = np.zeros((502, 13))
        op = np.zeros(502)
        zd = np.zeros(502)
        sources = list(folder.glob('*.pdos_atm*'))
        assert len(sources) == 12
        for source in sources:
            a = np.loadtxt(source)
            assert np.array_equal(a[:, 0], raw_total[:, 0])
            orbital = re.search(r'\((\w)\)$', source.name)[1]
            if orbital == 's':
                summed[:, 0] += a[:, 1]
            elif orbital == 'p':
                summed[:, 1] += a[:, 1]
                summed[:, 2:5] += a[:, 2:5]
                if '(O)' in source.name:
                    op += a[:, 1]
            elif orbital == 'd':
                summed[:, 5] += a[:, 1]
                summed[:, 6:11] += a[:, 2:7]
                zd += a[:, 1]
            else:
                raise AssertionError(source)
            summed[:, 12] += a[:, 1]
        assert np.allclose(summed, pdos[:, 1:], atol=1e-9)
        vbm, cbm = bands[:, 25].max(), bands[:, 26].min()
        ground = file('*GROUND*.in').read_text()
        nscf = file('*NSCF.in').read_text()
        for deck in [ground, nscf, file('*Bands.in').read_text()]:
            assert ('HUBBARD (ortho-atomic)' in deck) == (case != 'reference')
            if case != 'reference':
                assert 'U O-2p 7' in deck and 'U Zn-3d 10' in deck
        assert np.isclose(float(re.search(r'ecutwfc\s*=\s*(\S+)', ground)[1].rstrip(',')), m['ecutwfc_Ry'])
        trace = m['trace']
        final_force = trace[-1]['maximum_force_component_eV_A']
        valid_relax = None if case == 'native' else final_force <= .05 + 1e-6
        assert valid_relax == {'reference': True, 'hubbard': False, 'native': None}[case]
        summary[case] = dict(volume_A3=atoms.get_volume(), vbm_relative_to_band_reference_eV=float(vbm),
            sampled_separation_eV=float(cbm-vbm), spectrum_usable_for_illustration=case != 'hubbard',
            gap_scope='sampled path only; not a convergence certificate',
            DOS_integral_states_in_window=float(np.sum(np.diff(dos[:, 0])*(dos[:-1, 1]+dos[1:, 1])/2)),
            DOS_minus_band_reference_eV=m['dos_reference_eV']-m['band_reference_eV'],
            final_force_pass=valid_relax, final_force_component_eV_A=final_force,
            raw_total_vs_summed_PDOS_max_rounding_difference=float(np.max(np.abs(raw_total[:, 2]-pdos[:, -1]))))
        data[case] = (x, ticks, bands-vbm, pdos[:, 0]+m['dos_reference_eV']-(vbm+m['band_reference_eV']), op, zd)
    plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
    fig, axs = plt.subplots(3, 1, figsize=(8, 8), sharex=True, layout='constrained')
    for case, color, label in [('reference','#2266a6','PBE, 1400 eV'),('hubbard','#bd372c','Historical U, 340 eV (invalid)')]:
        t = meta[case]['trace']; n = np.arange(len(t)); e = np.array([r['energy_eV'] for r in t])
        for ax, key in zip(axs[:2], ['volume_A3','pressure_GPa']):
            ax.plot(n, [r[key] for r in t], 'o-', color=color, label=label)
        axs[2].plot(n, e-e[0], 'o-', color=color)
        for ax, val in zip(axs, [t[-1]['volume_A3'],t[-1]['pressure_GPa'],e[-1]-e[0]]):
            ax.scatter(n[-1], val, marker='X', s=110, color=color, zorder=5)
    axs[0].set_ylabel('Cell volume (Å³)'); axs[0].legend(fontsize=9)
    axs[1].set_ylabel('Pressure (GPa)'); axs[1].set_yscale('symlog', linthresh=.1)
    axs[2].set_ylabel('E − initial E (eV/cell)'); axs[2].set_xlabel('SCF cycle index (including final recheck)')
    axs[0].set_title('ZnO QE relaxation audit — X marks final rebuilt-basis SCF')
    for ax in axs: ax.grid(alpha=.2)
    fig.savefig(ROOT/'zno-qe-relaxation-audit.png',dpi=170); plt.close(fig)
    fig, axs = plt.subplots(1,4,figsize=(12,5),width_ratios=[2,1,2,1],sharey=True,layout='constrained')
    for j,case,title in [(0,'reference','PBE / relaxed / 1400 eV'),(2,'native','PBE+U / fixed / 800 eV')]:
        x,ticks,bands,energy,op,zd=data[case]
        axs[j].plot(x,bands,color='#2266a6',lw=.75)
        axs[j].set_xticks(x[ticks], ['A','L','M','Γ','A','H','K','Γ'])
        axs[j].set_xlim(x[0],x[-1]); axs[j].set_xlabel('Path distance (Å⁻¹)');axs[j].set_title(title,fontsize=10)
        axs[j+1].plot(op,energy,label='O p',color='#398448')
        axs[j+1].plot(zd,energy,label='Zn d',color='#ac6220')
        axs[j+1].set_xlim(left=0);axs[j+1].set_xlabel('states/eV/cell');axs[j+1].legend(fontsize=8)
    for ax in axs: ax.axhline(0,color='gray',ls=':',lw=.8); ax.set_ylim(-10,5)
    axs[0].set_ylabel('Energy − own sampled VBM (eV)')
    fig.suptitle('Different protocols: these spectra do not isolate the effect of U',fontsize=12)
    fig.savefig(ROOT/'zno-qe-bands-pdos.png',dpi=170);plt.close(fig)
    (ROOT/'derived-audit.json').write_text(json.dumps(summary,indent=2)+'\n')
    (ROOT/'checks.dat').write_text('PASS: source hashes, band/XML representations, reciprocal distances, stage references, DOS/PDOS grids, orbital sums, final force classification\nHistorical shared-U geometry: REJECTED (force tolerance exceeded)\n')
    print(json.dumps(summary,indent=2))

if __name__ == '__main__':
    main()

# Repeated GaAs GPAW example, 28 October 2026

Source: example-runs-Va5NDWGi/GPAW/bulk-gaas.
Nanoworks 27.2.0rc0, GPAW 26.7.0, ASE 3.29.0; 8 MPI processes.
Exact source commit and PAW package release were not recorded.
The logs identify Ga.LDA (valence 3, id e1f5b04e536df2d35180d97a9e5d9aca)
and As.LDA (valence 5, id 354e1067b5e66bdeaed68c554076e911).

This archive keeps original input, final CIF, band/DOS/atomic PDOS tables
and the ASE band-state JSON. Every file under data/ preserves its source bytes.
SHA256SUMS covers the distributed files except itself.
The documentation commit is not the source commit of this calculation.

## Regenerate figures and check exports

Install NumPy >=2 and Matplotlib in an analysis environment, then run:

    python plot_gaas.py

Outputs: gaas-gpaw-pdos.png, gaas-gpaw-repeat.png, checks.json.
No DFT engine or electronic state file is required.
The script checks long/XYYY/State band agreement, path metadata, finite data,
per-atom orbital sums and the exact sum from atoms to aggregate PDOS.
Atomic projections are not a complete partition of the total DOS.

For a comparison with the earlier tutorial, download gaas-gpaw-reference.zip
separately from the same tutorial page and run:

    python plot_gaas.py --previous /path/to/gaas-gpaw-reference.zip

The script compares numeric band, DOS and PDOS tables and verifies the input
is byte-identical. That is a repeatability check, not a convergence study.

## Recorded settings and results

LDA/PW, 300 eV; k-point density 2.5, effective Gamma-centred 5x5x5 ground grid.
Fermi-Dirac width 0.05 eV. Gaussian DOS width 0.1 eV, 501 samples.
Relaxed primitive edge 3.984084396516862 angstrom; conventional fcc edge
5.634346187193175 angstrom. Sampled direct gap at Gamma 0.4331102951002306 eV.
VBM -0.24440214622277878 eV, CBM 0.1887081488774518 eV relative to Ef.
No SOC or spin polarization. PAW setup choice, cutoff, geometry and sampling
convergence remain to be established. No experimental-gap claim is made.

Code and project data are distributed under LICENSE.md (MIT).
No third-party library source code is included.

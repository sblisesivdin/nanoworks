# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.
"""Redraw the 28 October GaAs run, checking exports without a DFT engine.

Requires NumPy >=2 and Matplotlib. Optionally compare with the older tutorial:
python plot_gaas.py --previous /path/to/gaas-gpaw-reference.zip
"""
from pathlib import Path
import argparse
import hashlib
import io
import json
import zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
PREFIX = 'bulk-gaas-results-'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--previous', type=Path)
args = parser.parse_args()


def read(suffix):
    return np.loadtxt(DATA / (PREFIX + suffix), skiprows=1)


bands = read('BAND-GPAW-Result-Band-XYYY.dat')
long = read('BAND-GPAW-Result-Band.dat')
dos = read('DOS-GPAW-Result-DOS.dat')
pdos = read('DOS-GPAW-Result-PDOS.dat')
kpath = np.loadtxt(DATA / (PREFIX + 'BAND-GPAW-Result-KPath.dat'), dtype=str, skiprows=1)
raw = np.loadtxt(DATA / (PREFIX + 'DOS-GPAW-Result-Raw-PDOS-Each-Atom.dat'), dtype=str, skiprows=1)
atoms = {symbol: raw[raw[:, 1] == symbol, 2:].astype(float) for symbol in ('Ga', 'As')}
assert set(raw[:, 0]) == {'1', '2'}
assert bands.shape == (40, 9) and dos.shape == (501, 2)
assert long.shape == (320, 2) and pdos.shape == (501, 14)
assert all(np.isfinite(a).all() for a in (bands, long, dos, pdos, *atoms.values()))
assert np.array_equal(bands[:, 0], np.arange(40))
assert np.array_equal(long[:, 0], np.tile(bands[:, 0], 8))
assert np.array_equal(long[:, 1].reshape(8, 40).T, bands[:, 1:])
assert np.array_equal(kpath[:, 0].astype(int), bands[:, 0])
assert np.all(np.diff(kpath[:, 1].astype(float)) > 0)
assert not np.any(kpath[:, 2].astype(int))
assert np.array_equal(pdos[:, 0], dos[:, 0])
for a in atoms.values():
    assert np.array_equal(a[:, 0], dos[:, 0])
    assert np.all(a[:, 1:] >= 0)
    assert np.allclose(a[:, 2], a[:, 3:6].sum(axis=1), atol=2e-14, rtol=0)
    assert np.allclose(a[:, 6], a[:, 7:12].sum(axis=1), atol=2e-14, rtol=0)
    assert np.allclose(a[:, -1], a[:, [1, 2, 6, 12]].sum(axis=1), atol=2e-14, rtol=0)
assert np.array_equal(atoms['Ga'][:, 1:] + atoms['As'][:, 1:], pdos[:, 1:])
vbm = float(bands[:, 4].max())
cbm = float(bands[:, 5].min())
assert set(bands[np.isclose(bands[:, 4], vbm, rtol=0, atol=1e-8), 0].astype(int)) == {11, 39}
assert set(bands[np.isclose(bands[:, 5], cbm, rtol=0, atol=1e-8), 0].astype(int)) == {11, 39}
state = json.loads((DATA / (PREFIX + 'BAND-GPAW-Result-State.json')).read_text())
shape, dtype, values = state['energies']['__ndarray__']
assert np.array_equal(np.array(values, dtype=dtype).reshape(shape)[0], bands[:, 1:])
assert state['reference'] == 0.0  # The archived energies are already E-Ef.
checks = {
    'gap_on_sampled_path_eV': cbm - vbm,
    'vbm_relative_to_Ef_eV': vbm,
    'cbm_relative_to_Ef_eV': cbm,
    'dos_integral_over_exported_window_states_per_cell': float(np.trapezoid(dos[:, 1], dos[:, 0])),
    'raw_atom_to_aggregate_pdos_max_error': float(abs(atoms['Ga'][:, 1:] + atoms['As'][:, 1:] - pdos[:, 1:]).max()),
}
if args.previous:
    differences = {}
    with zipfile.ZipFile(args.previous) as archive:
        for suffix in ['BAND-GPAW-Result-Band-XYYY.dat', 'BAND-GPAW-Result-Band.dat',
                       'DOS-GPAW-Result-DOS.dat', 'DOS-GPAW-Result-PDOS.dat']:
            old = np.loadtxt(io.StringIO(archive.read(PREFIX + suffix).decode()), skiprows=1)
            current = read(suffix)
            assert old.shape == current.shape
            differences[suffix] = float(abs(old - current).max())
        assert archive.read('bulk_gaas.py') == (DATA / 'bulk_gaas.py').read_bytes()
    checks['previous_run_maximum_absolute_table_differences'] = differences
(ROOT / 'checks.json').write_text(json.dumps(checks, indent=2) + '\n')

plt.rcParams.update({'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False})
colors = {'Ga s': '#a65718', 'Ga p': '#cb8c37', 'As s': '#176b91', 'As p': '#4299a8'}
fig, axes = plt.subplots(1, 2, figsize=(11, 4.7))
for ax, limits, title in zip(axes, [(-13.1, 8.92), (-2, 2)], ['Full exported energy window', 'Near the band edges']):
    ax.plot(dos[:, 0], dos[:, 1], color='0.25', lw=1.0, alpha=.7, label='Total DOS')
    for symbol, a in atoms.items():
        for orbital, col in [('s', 1), ('p', 2)]:
            label = symbol + ' ' + orbital
            ax.plot(a[:, 0], a[:, col], label=label, color=colors[label],
                    ls='-' if orbital == 'p' else '--', lw=1.5)
    ax.axvspan(vbm, cbm, color='#8ab7a1', alpha=.16, label='Sampled eigenvalue gap')
    ax.axvline(0, color='0.3', ls=':', lw=.8)
    ax.set(xlim=limits, ylim=(0, None), xlabel=r'$E-E_F$ (eV)', ylabel='States / (eV cell)', title=title)
axes[0].legend(ncol=2, fontsize=8, frameon=False)
fig.suptitle('GaAs | atom-projected s and p DOS, GPAW/LDA')
fig.text(.5, .015, '28 Oct 2026 run; Gaussian width 0.1 eV. Projector weights are qualitative; atomic PDOS need not sum to total DOS.', ha='center', fontsize=9)
fig.tight_layout(rect=(0, .06, 1, .94))
fig.savefig(ROOT / 'gaas-gpaw-pdos.png', dpi=180)
plt.close(fig)

fig, (ax, dx) = plt.subplots(1, 2, figsize=(8.5, 5), sharey=True,
                             gridspec_kw={'width_ratios': [2, 1]})
distance = kpath[:, 1].astype(float)
for b in bands[:, 1:].T:
    ax.plot(distance, b, color='#176b91', lw=1.2)
special = kpath[:, 3] != '-'
ticks = distance[special]
labels = [r'$\Gamma$' if t == 'G' else t for t in kpath[special, 3]]
for tick in ticks:
    ax.axvline(tick, color='0.85', lw=.7)
ax.set(xticks=ticks, xticklabels=labels, ylabel=r'$E-E_F$ (eV)', ylim=(-5, 10), xlim=(distance[0], distance[-1]))
dx.plot(dos[:, 1], dos[:, 0], color='#ae4c20')
dx.set(xlabel='DOS (states/eV/cell)', xlim=(0, None))
for axis in (ax, dx):
    axis.axhline(0, color='0.3', ls='--', lw=.8)
fig.suptitle('GaAs | repeated GPAW/LDA band and DOS calculation')
fig.tight_layout()
fig.savefig(ROOT / 'gaas-gpaw-repeat.png', dpi=180)
plt.close(fig)
print(json.dumps(checks, indent=2))

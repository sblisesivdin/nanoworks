# Recorded GPAW silicon convergence sweeps

Source: example-runs-Va5NDWGi/GPAW/silicon-convergence, 28 October 2026.
Tutorial: https://nanoworks.readthedocs.io/en/latest/tutorials/silicon-convergence.html#tutorial-convergence-gpaw

The archived input and starting Si.cif matched the repository example during
review. GPAW 26.7.0, ASE 3.29.0, eight processes; PBE, spin off,
Fermi-Dirac width 0.05 eV, normal SCF preset. Si PBE setup id:
ee77bee481871cc2cb65ac61239ccafa. Exact run commit and PAW dataset
package release were not recorded.

With NumPy 2 or newer and Matplotlib installed, run:

    python plot_convergence.py

The script verifies source hashes, table energies, SCF-derived metadata,
convergence selections, volume scaling and the quadratic fit. It writes
checks.dat and two figures. No DFT engine is imported.
Original input/CIF/DAT bytes are unchanged. Generated PNGs/checks.dat are
excluded from SHA256SUMS so they can be recreated.

The 10 meV/atom, two-adjacent-difference criterion selects 400 eV and density
4.0. Densities 2,3,4,5 correspond to 4^3,6^3,8^3,10^3 meshes at the original
cell. Density uses the GPAW/ASE points-per-inverse-angstrom convention;
archived points/A table labels/comments are retained as originally written.
The cutoff sweep uses density 3; k-point and lattice sweeps use 400 eV.

The lattice sweep keeps density 4, which gives 9^3 meshes at scales 0.96/0.98
and 8^3 at 1.00/1.02/1.04. Mesh changes can influence the energy-volume curve.
The selected CIF is the calculated minimum at scale 1.00 (V=40.8882927451 A^3),
not the quadratic fit minimum (V=41.4612958156 A^3). The five-point fit has
RMS residual 3.912 meV/atom; the fitted scale was not separately evaluated.
No converged equation of state or bulk modulus is established.

recorded-scf-metadata.dat was extracted from all 13 original gpaw-scf.txt
files: sweep/parameter, cutoff (eV), density, mesh, irreducible count,
SCF steps and the printed extrapolated total energy (eV).
These rounded energies agree with the original table within 5.1e-7 eV.
The table's nan volume entries for non-lattice tasks are expected.
recorded-reference.dat contains the original JSON's selections and fit values.
The original JSON (with absolute paths) and machine-specific logs are omitted.

To also verify the original SCF files when they are available locally:

    python plot_convergence.py --log-dir /path/to/Si-GPAW-convergence-results

SCF-SHA256SUMS retains their original relative paths and SHA256 values.
The table-based plotting package does not replace Nanoworks' JSON-based
--plot-results CLI format. Tighten and jointly check cutoff, k mesh and the
target observable before using selected settings for research.

# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.

"""Verify and redraw the recorded GPAW Si convergence sweeps."""
from pathlib import Path
import argparse
import ast
import hashlib
import re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--log-dir', type=Path,
                        help='Optional original result directory containing cutoff/kpoints/lattice SCF logs')
    args = parser.parse_args()
    manifest = ROOT/'SHA256SUMS'
    if manifest.exists():
        for line in manifest.read_text().splitlines():
            digest, name = line.split('  ', 1)
            assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest, name
    data = np.genfromtxt(ROOT/'convergence-results.dat', skip_header=1,
        dtype=[('task','U12'),('kind','U24'),('parameter',float),('volume',float),
               ('energy',float),('per_atom',float)])
    metadata = np.genfromtxt(ROOT/'recorded-scf-metadata.dat', comments='#',
        dtype=[('task','U12'),('parameter',float),('cutoff',float),('density',float),
               ('nx',int),('ny',int),('nz',int),('ibz',int),('steps',int),('printed_energy',float)])
    assert len(data)==len(metadata)==13
    assert np.array_equal(data['task'],metadata['task'])
    assert np.array_equal(data['parameter'],metadata['parameter'])
    assert np.all(np.isfinite(data['energy'])) and np.all(metadata['steps']>0)
    np.testing.assert_allclose(data['energy'],2*data['per_atom'],atol=1e-14,rtol=0)
    np.testing.assert_allclose(data['energy'],metadata['printed_energy'],atol=5.1e-7,rtol=0)
    settings={}
    for node in ast.parse((ROOT/'Si-GPAW-convergence.py').read_text()).body:
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
            settings[node.targets[0].id]=ast.literal_eval(node.value)
    tolerance=settings['Convergence_energy_tolerance']
    consecutive=settings['Convergence_consecutive_points']
    reference={line.split()[0]:float(line.split()[1]) for line in
               (ROOT/'recorded-reference.dat').read_text().splitlines() if not line.startswith('#')}
    sweeps={k:data[data['task']==k] for k in ['cutoff','kpoints','lattice']}
    checks=[]
    for task, name in [('cutoff','cutoff_selected'),('kpoints','density_selected')]:
        rows=sweeps[task]
        key='Convergence_cutoffs' if task=='cutoff' else 'Convergence_kpoints'
        assert np.array_equal(rows['parameter'],settings[key])
        delta=np.abs(np.diff(rows['per_atom']))
        qualifying=[i for i in range(1,len(rows)-consecutive+1)
                    if np.all(delta[i-1:i-1+consecutive]<=tolerance)]
        assert qualifying
        assert rows['parameter'][qualifying[0]]==reference[name]
        checks.extend((f'{task}_delta_{i+1}',v*1000,'meV/atom') for i,v in enumerate(delta))
    lat=sweeps['lattice'];meta=metadata[metadata['task']=='lattice']
    assert np.array_equal(lat['parameter'],settings['Convergence_lattice_scales'])
    v0=float(lat['volume'][lat['parameter']==1][0])
    np.testing.assert_allclose(lat['volume'],v0*lat['parameter']**3,atol=1e-12,rtol=1e-13)
    minimum=int(np.argmin(lat['per_atom']))
    assert 0<minimum<len(lat)-1
    assert lat['parameter'][minimum]==reference['scale_selected']
    assert np.all(meta['cutoff']==reference['cutoff_selected'])
    assert np.all(meta['density']==reference['density_selected'])
    assert np.array_equal(meta['nx'],[9,9,8,8,8])
    coefficients=np.polyfit(lat['volume'],lat['per_atom'],2)
    assert coefficients[0]>0
    fit_volume=-coefficients[1]/(2*coefficients[0])
    fit_energy=np.polyval(coefficients,fit_volume)
    assert lat['volume'].min()<fit_volume<lat['volume'].max()
    assert abs(fit_volume-reference['fit_volume'])<1e-9
    assert abs(fit_energy-reference['fit_energy'])<1e-12
    residual=(lat['per_atom']-np.polyval(coefficients,lat['volume']))*1000
    checks.extend([('fit_volume',fit_volume,'angstrom^3/cell'),
                   ('fit_energy',fit_energy,'eV/atom'),
                   ('fit_rms_residual',float(np.sqrt(np.mean(residual**2))),'meV/atom'),
                   ('discrete_volume',v0,'angstrom^3/cell')])
    if args.log_dir:
        for line,row in zip((ROOT/'SCF-SHA256SUMS').read_text().splitlines(),metadata):
            digest,name=line.split('  ',1);content=(args.log_dir/name).read_bytes()
            assert hashlib.sha256(content).hexdigest()==digest,name
            text=content.decode();assert 'Converged in ' in text
            energy=float(re.findall(r'Extrapolated:\s*([-\d.]+)',text)[-1])
            assert energy==row['printed_energy']
        print('All 13 original SCF log hashes and printed energies verified.')
    (ROOT/'checks.dat').write_text('# quantity value unit\n'+
        ''.join(f'{k} {v:.15g} {u}\n' for k,v,u in checks))

    plt.rcParams.update({'font.size':10.5,'axes.spines.top':False,
                         'axes.spines.right':False,'savefig.dpi':180})
    fig,axes=plt.subplots(1,2,figsize=(10.3,4.0))
    for ax,task,name in zip(axes,['cutoff','kpoints'],['cutoff_selected','density_selected']):
        rows=sweeps[task];x=rows['parameter'];y=(rows['per_atom']-rows['per_atom'][-1])*1000
        ax.plot(x,y,'o-',color='#246ca6',lw=1.4)
        ax.axvline(reference[name],color='#c1682b',ls='--',lw=1.2,label='Selected candidate')
        ax.set(xticks=x,ylabel='Energy relative to last sample (meV/atom)')
        if task=='cutoff':ax.set(xlabel='Plane-wave cutoff (eV)',title='Cutoff scan at fixed density 3.0')
        else:
            ax.set(xlabel=r'Density (points per $\AA^{-1}$)',title='k-point scan at selected cutoff 400 eV')
            for xx,yy,n in zip(x,y,[4,6,8,10]):ax.annotate(f'{n}³',(xx,yy),xytext=(5,8),textcoords='offset points',fontsize=9)
        ax.margins(y=0.2)
    axes[0].legend(frameon=False,fontsize=9)
    fig.tight_layout();fig.savefig(ROOT/'silicon-gpaw-convergence.png',bbox_inches='tight');plt.close(fig)

    fig,axes=plt.subplots(1,2,figsize=(10.3,4.2))
    vv=np.linspace(lat['volume'].min(),lat['volume'].max(),250)
    axes[0].plot(vv,(np.polyval(coefficients,vv)-lat['per_atom'][minimum])*1000,
                 color='#56616d',lw=1.3,label='Quadratic fit to all five points')
    for ax,yy in zip(axes,[(lat['per_atom']-lat['per_atom'][minimum])*1000,residual]):
        for nx,colour,marker in [(9,'#c1682b','^'),(8,'#246ca6','o')]:
            mask=meta['nx']==nx
            ax.scatter(lat['volume'][mask],yy[mask],color=colour,marker=marker,s=42,label=f'{nx}³ electronic mesh',zorder=3)
        ax.set_xlabel(r'Primitive-cell volume ($\AA^3$)')
    axes[0].axvline(v0,color='#246ca6',ls=':',lw=1,label='Calculated minimum')
    axes[0].axvline(fit_volume,color='#56616d',ls='--',lw=1,label='Interpolated fit minimum')
    axes[0].set(ylabel='Energy relative to calculated minimum (meV/atom)',title='Lattice scan at density 4.0')
    axes[0].legend(frameon=False,fontsize=8)
    axes[1].axhline(0,color='#a1aab4',lw=.7)
    axes[1].set(ylabel='Calculated energy minus fit (meV/atom)',
                title=f'Quadratic residuals: RMS {np.sqrt(np.mean(residual**2)):.3f} meV/atom')
    fig.tight_layout();fig.savefig(ROOT/'silicon-gpaw-convergence-lattice.png',bbox_inches='tight');plt.close(fig)
    print('Sweep records, SCF metadata, selections and quadratic fit verified.')
    for k,v,u in checks:print(f'{k}: {v:.10g} {u}')


if __name__=='__main__':main()

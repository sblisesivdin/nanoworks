# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.

"""Replot the supplied optical DAT files without running a DFT engine."""

from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


def main():
    root = Path(__file__).resolve().parent
    staged = {axis: np.loadtxt(root / 'staged' / f'optical-{axis}.dat', skiprows=1)
              for axis in 'xyz'}
    combined = np.loadtxt(root / 'combined' / 'optical-x.dat', skiprows=1)
    plt.rcParams.update({
        'font.family': 'DejaVu Sans', 'font.size': 10,
        'axes.spines.top': False, 'axes.spines.right': False,
        'axes.titleweight': 'bold', 'axes.labelcolor': '#243343',
        'text.color': '#243343', 'axes.edgecolor': '#8995a0',
        'grid.color': '#dce3e9', 'grid.alpha': .65,
        'savefig.facecolor': 'white',
    })
    blue, orange = '#17699c', '#cc6b35'
    e, er, ei, n, k, alpha, reflectivity = staged['x'].T
    fig, axes = plt.subplots(2, 2, figsize=(11.4, 7.6), constrained_layout=True)
    fig.suptitle('Silicon with QE: read the optical outputs\n'
                 r'PBE · $4\times4\times4$ optical mesh · 8 bands · $\eta=0.05$ eV',
                 fontsize=14)
    a, b, c, d = axes.flat
    a.plot(e, er, color=blue, lw=1.35, label=r'$\epsilon_1$')
    a.plot(e, ei, color=orange, lw=1.35, label=r'$\epsilon_2$')
    a.axhline(0, color='#8995a0', lw=.65)
    a.set(title='(a) Dielectric response, x direction', ylabel='Dielectric function (dimensionless)')
    a.legend(frameon=False, ncol=2)
    b.plot(e, n, color=blue, lw=1.35, label=r'$n$')
    b.plot(e, k, color=orange, lw=1.35, label=r'$\kappa$')
    b.set(title='(b) Complex refractive index', ylabel='Index (dimensionless)')
    b.legend(frameon=False)
    c.plot(e, alpha / 1e5, color=blue, lw=1.35)
    c.set(title='(c) Absorption coefficient', ylabel=r'$\alpha$ ($10^5$ cm$^{-1}$)')
    d.plot(e, reflectivity * 100, color=blue, lw=1.35)
    d.set(title='(d) Normal-incidence reflectivity', ylabel='Reflectivity (%)', ylim=(0, 100))
    for ax in axes.flat:
        ax.set(xlim=(0, 20), xlabel='Photon energy (eV)')
        ax.grid(True, linewidth=.6)
    fig.supxlabel('Recorded coarse teaching run; spectrum and low-energy values are not converged.',
                  fontsize=10, color='#7a3f28')
    fig.savefig(root / 'silicon-qe-optics.png', dpi=190)
    plt.close(fig)

    fig, (a, b) = plt.subplots(1, 2, figsize=(11.4, 4.5), constrained_layout=True)
    fig.suptitle('Numerical checks before interpreting a spectrum', fontsize=14)
    a.plot(combined[:, 0], combined[:, 2], color=orange, lw=1.3,
           label=r'Combined: $2^3$ mesh, $\eta=0.10$ eV')
    a.plot(e, ei, color=blue, lw=1.3,
           label=r'Staged: $4^3$ mesh, $\eta=0.05$ eV')
    a.set(title='(a) Two smoke configurations', ylabel=r'$\epsilon_2$ (dimensionless)',
          xlabel='Photon energy (eV)', xlim=(0, 10))
    a.legend(frameon=False, fontsize=9)
    b.plot(e, staged['y'][:, 2] - ei, color=blue, lw=1.3,
           label=r'$\epsilon_{2,y}-\epsilon_{2,x}$')
    b.plot(e, staged['z'][:, 2] - ei, color=orange, lw=1.3,
           label=r'$\epsilon_{2,z}-\epsilon_{2,x}$')
    b.set(title='(b) Residual directional differences, staged run',
          ylabel=r'Difference in $\epsilon_2$ (dimensionless)',
          xlabel='Photon energy (eV)', xlim=(0, 10))
    b.legend(frameon=False, fontsize=9)
    for ax in (a, b):
        ax.grid(True, linewidth=.6)
    fig.supxlabel('Mesh, linewidth and energy sampling differ together: this is not an isolated convergence scan.',
                  fontsize=10, color='#7a3f28')
    fig.savefig(root / 'silicon-qe-optics-checks.png', dpi=190)
    plt.close(fig)


if __name__ == '__main__':
    main()

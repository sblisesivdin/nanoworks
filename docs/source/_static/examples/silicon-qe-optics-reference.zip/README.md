# Silicon QE optical reference data

Source: example-runs-Va5NDWGi, QE/silicon-optical-stages and QE/silicon-combined-rpa, completed 28 October 2026.
Nanoworks 27.2.0rc0, ASE 3.29.0, QE 7.4.1; eight MPI processes.
The exact run source commit and pseudopotential package version were not recorded.

These are completed coarse teaching workflows, not production-converged optical spectra.
The staged setup uses 4x4x4 optical points, eight bands, 0.05 eV linewidth and 1001 samples to 20 eV.
The combined setup uses 2x2x2 points, eight bands, 0.10 eV linewidth and 101 samples to 10 eV.
Their differences are not an isolated k-point convergence test.

All original optical DAT headers include units. Six direction tables are retained byte-for-byte.
The staged raw epsr/epsi/eels/ieps files come directly from epsilon.x.
checks.dat summarizes first samples, sampled maxima and residual Cartesian differences.
The first energy (0.001 eV) is not the zero-frequency limit.
Do not interpret a broadened optical tail or a peak as a converged fundamental gap.

Reproduce both tutorial figures with:

    python plot_optics.py

Requires NumPy and Matplotlib only. No DFT engine or saved wavefunctions are needed.
The plotting script does not smooth or normalize the supplied spectra.
Absorption is shown in units of 100000/cm and reflectivity as a percentage.

Inputs are provided for provenance. For the staged input, pass -E QE explicitly and run ground first,
then the optical-only input. Its Engine=GPAW setting is overridden by -E QE.
For DOS, the recorded ground command also used -s DOS_integration=tetrahedron.
All four input/structure files match the source checkout aac9c7708b306c2fbf416e39061bb143e0adf7f6 byte-for-byte;
that check does not identify the source commit used to execute the original runs.

No private state directories, wavefunctions or host paths are included.

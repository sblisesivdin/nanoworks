# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.

"""Verify and plot archived GPAW RPA data, without importing any DFT engine."""
from pathlib import Path
import hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
PREFIX = 'Si_mp-149_primitive_Example-OPTICAL-GPAW-Result-Calculation-RPA'
HBAR = 6.582119569e-16  # eV s
C = 2.99792458e10  # cm/s


def table(case, mode, axis='x'):
    return np.loadtxt(ROOT / case / f'{PREFIX}-{mode}-AllData_{axis}direction.dat', skiprows=1)


def main():
    manifest = ROOT / 'SHA256SUMS'
    if manifest.exists():
        for line in manifest.read_text().splitlines():
            digest, name = line.split('  ', 1)
            if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest:
                raise ValueError('Source hash mismatch: ' + name)
    rows = []
    for case, count in [('staged', 157), ('combined', 79)]:
        for mode in ['NLFC', 'LFC']:
            data = table(case, mode)
            assert data.shape == (count, 7)
            assert np.isfinite(data).all()
            energy, e1, e2, n, k, alpha, reflection = data.T
            assert energy[0] == 0 and np.all(np.diff(energy) > 0)
            assert np.all(data[:, 2:6] >= 0)
            assert np.all((reflection >= 0) & (reflection <= 1))
            np.testing.assert_allclose(n*n-k*k, e1, rtol=2e-10, atol=3e-9)
            np.testing.assert_allclose(2*n*k, e2, rtol=2e-10, atol=3e-9)
            np.testing.assert_allclose(alpha, 2*energy*k/(HBAR*C), rtol=2e-11, atol=1e-8)
            np.testing.assert_allclose(reflection,
                ((n-1)**2+k*k)/((n+1)**2+k*k), rtol=2e-10, atol=3e-12)
            for axis in 'xyz':
                other = table(case, mode, axis)
                raw = np.loadtxt(ROOT / case / f'{PREFIX}_dielec_{axis}direction.csv', delimiter=',')
                columns = [0, 1, 2] if mode == 'NLFC' else [0, 3, 4]
                assert np.array_equal(other[:, :3], raw[:, columns])
                # Cubic isotropy is a consistency check, not convergence evidence.
                assert np.array_equal(other, data)
            peak = int(np.argmax(e2))
            values = [
                ('points', len(data), '1'), ('epsilon1_at_zero', e1[0], '1'),
                ('epsilon2_peak_energy', energy[peak], 'eV'),
                ('epsilon2_peak_height', e2[peak], '1'),
                ('maximum_absorption', float(alpha.max()), '1/cm'),
                ('max_n2_k2_residual', float(np.max(np.abs(n*n-k*k-e1))), '1'),
                ('max_2nk_residual', float(np.max(np.abs(2*n*k-e2))), '1'),
            ]
            rows.extend((f'{case}_{mode}_{name}', value, unit) for name, value, unit in values)
    (ROOT / 'checks.dat').write_text('# quantity value unit\n' +
        ''.join(f'{key} {value:.14g} {unit}\n' for key, value, unit in rows))

    plt.rcParams.update({'font.size': 10.5, 'axes.spines.top': False,
                         'axes.spines.right': False, 'savefig.dpi': 180})
    colours = {'NLFC': '#246ca6', 'LFC': '#c1682b'}
    labels = {'NLFC': 'Without local fields', 'LFC': 'With local fields'}
    fig, axes = plt.subplots(2, 2, figsize=(10.2, 7.2), sharex=True)
    for i, case in enumerate(['staged', 'combined']):
        for mode in ['NLFC', 'LFC']:
            a = table(case, mode)
            for j, column in enumerate([1, 2]):
                axes[i, j].plot(a[:, 0], a[:, column], color=colours[mode],
                                lw=1.35, label=labels[mode])
        axes[i, 0].set_ylabel(r'$\epsilon_1$ (dimensionless)')
        axes[i, 1].set_ylabel(r'$\epsilon_2$ (dimensionless)')
        title = 'Staged: 4³ grid, 100 eV response cutoff, η = 0.05 eV' if i == 0 else \
                'Combined smoke: 2³ grid, 30 eV response cutoff, η = 0.10 eV'
        for ax in axes[i]:
            ax.set_title(title, fontsize=9)
            ax.axhline(0, color='#a1aab4', lw=0.6)
            ax.set_xlim(0, 8)
        axes[i, 1].set_ylim(bottom=0)
    axes[0, 0].legend(frameon=False, fontsize=9)
    for ax in axes[-1]: ax.set_xlabel('Photon energy (eV)')
    fig.tight_layout()
    fig.savefig(ROOT / 'silicon-gpaw-rpa.png', bbox_inches='tight')
    plt.close(fig)

    fig, axes = plt.subplots(2, 2, figsize=(10.0, 6.8), sharex=True)
    for mode in ['NLFC', 'LFC']:
        a = table('staged', mode)
        axes[0, 0].plot(a[:, 0], a[:, 3], color=colours[mode], lw=1.4, label=labels[mode])
        axes[0, 1].plot(a[:, 0], a[:, 4], color=colours[mode], lw=1.4)
        axes[1, 0].plot(a[:, 0], a[:, 5]/1e5, color=colours[mode], lw=1.4)
        axes[1, 1].plot(a[:, 0], a[:, 6], color=colours[mode], lw=1.4)
    for ax, title, ylabel in zip(axes.flat,
        ['Refractive index', 'Extinction index', 'Absorption coefficient', 'Normal-incidence reflectivity'],
        ['n (dimensionless)', 'κ (dimensionless)', r'α ($10^5$ cm$^{-1}$)', 'R (fraction)']):
        ax.set(title=title, ylabel=ylabel, xlim=(0, 8))
        ax.set_ylim(bottom=0)
    axes[1, 1].set_ylim(0, 1)
    axes[0, 0].legend(frameon=False, fontsize=9)
    for ax in axes[-1]: ax.set_xlabel('Photon energy (eV)')
    fig.suptitle('Staged Si RPA: quantities derived from the same dielectric spectrum', fontsize=12)
    fig.tight_layout()
    fig.savefig(ROOT / 'silicon-gpaw-rpa-derived.png', bbox_inches='tight')
    plt.close(fig)
    print('Verified 12 DAT tables against 6 CSV files; optical identities and isotropy passed.')
    for key, value, unit in rows:
        print(f'{key}: {value:.10g} {unit}')


if __name__ == '__main__':
    main()

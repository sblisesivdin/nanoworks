# Recorded silicon GPAW RPA spectra

Source: example-runs-Va5NDWGi/GPAW/silicon-optical-stages and
GPAW/silicon-combined-rpa, 28 October 2026.
Tutorial: https://nanoworks.readthedocs.io/en/latest/examples/silicon-gpaw-rpa.html

Nanoworks 27.2.0rc0, GPAW 26.7.0, ASE 3.29.0, eight processes.
Exact run commit and PAW dataset package release were not recorded.
Si PBE setup id: ee77bee481871cc2cb65ac61239ccafa.

Both cases use fixed two-atom bulk Si, PBE/PW 340 eV, spin/SOC off,
Fermi-Dirac occupation width 0.05 eV and eight optical bands.
Staged: ground/optical Gamma 4x4x4, response cutoff 100 eV, eta 0.05 eV,
initial nonlinear energy spacing 0.05 eV, omega2 5 eV, 157 energy samples.
Combined smoke: Gamma 2x2x2, response cutoff 30 eV, eta 0.1 eV,
initial nonlinear energy spacing 0.1 eV, omega2 5 eV, 79 samples.
These cases change several parameters simultaneously; this is not a
controlled staged/combined equivalence or convergence test.

Run with NumPy and Matplotlib installed:

    python plot_rpa.py

The script verifies SHA256SUMS, checks 12 DAT spectra against 6 raw CSVs,
checks optical identities and x/y/z agreement, writes checks.dat and the
same two tutorial figures. No GPAW or new calculations are required.
The plots show 0-8 eV; the source spectra span 0-22.044681 eV.
Generated PNGs/checks.dat are excluded from SHA256SUMS so they can be redrawn.
Original Python, CIF, CSV and DAT files retain their original bytes.

DAT columns: energy (eV), epsilon1, epsilon2, n, kappa, alpha (1/cm),
reflectivity (fraction). Raw CSV columns: energy (eV), NLFC epsilon1,
NLFC epsilon2, LFC epsilon1, LFC epsilon2; raw CSVs have no header.
NLFC means without local fields; LFC means with local fields, within RPA.
Local-field comparison does not compare RPA with BSE.

The original staged folder was later reused for BSE; its common optical
summary/state/log can refer to that later method. These RPA tables were
reviewed against their method-specific log and zero RPA exit code.
The combined RPA summary's six table hashes were verified during review.
The plotting package omits those logs/summaries and electronic state files.

Large peaks and zero-energy values are outputs of coarse demonstration
settings, not converged Si predictions. Optical identities and cubic isotropy
check consistency; they do not establish convergence or an optical gap.

# ZnO GPAW PBE/PBE+U audit

Run `python plot_zno.py` with NumPy, Matplotlib, ASE and spglib. The stored
FixSymmetry constraints need spglib. No GPAW installation is needed. It verifies
source hashes, AST input differences, trajectory geometry, all printed optimizer
free-energy/fmax rows, long/XYYY/State bands, path distances, gaps and PDOS sums.
It generates two figures, checks.dat, relaxation-audit and orbital-audit tables.
Optional `--log-dir /path/to/zno-review` verifies original inspected-log hashes;
that tree has reference/ and hubbard/ subdirectories.

Original inputs/CIFs/TRAJs/State JSON/DATs preserve their source bytes.
recorded-optimization.dat is a derived transcription of the original LBFGS
stdout rows. SOURCE-SHA256SUMS covers original files; LOG-SHA256SUMS identifies
inspected logs; SHA256SUMS covers package files except itself. Raw machine logs
and GPWs are excluded. provenance.json records settings and known limits.
LICENSE.md contains project licensing.

IMPORTANT: These are NOT controlled U-only comparison runs. The reference uses
1400eV and the U run340eV. Both start from47.56645A^3 and relax; final volumes
49.27273A^3 and27.63737A^3 differ strongly. Hubbard contraction41.90% and an
increase of6.572651eV in its free energy require investigation. Meeting the
0.05eV/A cell-filter force stopping rule does not validate a physical structure.
Nonmonotone LBFGS energy alone does not identify a particular code bug.

The plot reconstructs FrechetCellFilter with the initial cell as orig_cell;
energies are force-consistent free energies, each shifted by its own initial
value. Do not compare absolute total energies between the two models.

The recorded direct path gaps at Gamma are0.742106058783eV and4.268562841154eV.
The latter is an audit-only result of a contracted, unvalidated structure.
Both band arrays have40points/36spin-degenerate bands with18occupied bands
(36electrons per4atomcell). The duplicate Gamma endpoints differ by<1e-9eV.
Energies in source DATs/State are already Ef-relative (State reference0eV).
Figures add a shift to each run's own sampled path VBM; no absolute band offsets
are established. Zn-d/O-p projections sum both sites per element and are not
an exact decomposition of total DOS. Cutoff, kmesh, geometry, PAW model and
DFT+U projection normalization remain part of the interpretation.

The tutorial supplies a NEW fixed-initial-geometry comparison protocol using
Geo_optim=False, a common1400eV cutoff and separate output directories. Those
runs were not used to generate these archived figures. Common1400eV is not a
GPAW convergence certificate. The source input files retain their old flags.
QE uses different projector/pseudopotential conventions and requires a separate
audit. The original Hubbard settings are O-2p7eV, Zn-3d10eV, GPAW scale=True;
these are illustrative model choices, not fitted or linear-response U values.

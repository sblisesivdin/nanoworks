# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.

"""Audit recorded ZnO runs with NumPy, Matplotlib, ASE and spglib; no GPAW."""
import argparse
import ast
import hashlib
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ase.build import bulk
from ase.filters import FrechetCellFilter
from ase.io import read
from ase.spectrum.band_structure import BandStructure
from ase.units import GPa

ROOT = Path(__file__).resolve().parent


def assignments(path):
    return {n.targets[0].id: n.value for n in ast.parse(path.read_text()).body
            if isinstance(n, ast.Assign)}


def load(case, pattern, **kwargs):
    return np.loadtxt(next((ROOT / case).glob(pattern)), skiprows=1, **kwargs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--log-dir', type=Path, help='Optional original reference/ and hubbard/ log tree')
    args = parser.parse_args()
    for line in (ROOT / 'SOURCE-SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    if args.log_dir:
        for line in (ROOT / 'LOG-SHA256SUMS').read_text().splitlines():
            digest, name = line.split('  ', 1)
            assert hashlib.sha256((args.log_dir / name).read_bytes()).hexdigest() == digest, name
    configs = {case: assignments(next((ROOT / case).glob('*.py'))) for case in ['reference', 'hubbard']}
    differences = {key for key in configs['reference']
                   if ast.dump(configs['reference'][key]) != ast.dump(configs['hubbard'][key])}
    assert differences == {'Outdirname', 'Wavefunction_cutoff', 'Hubbard_U'}
    initial = bulk('ZnO', 'wurtzite', a=3.25, c=5.2)
    records = (ROOT / 'recorded-optimization.dat').read_text().splitlines()[1:]
    all_data, checks = {}, []
    for case, count, cutoff, expected_gap in [('reference', 3, 1400, .7421060587828743),
                                               ('hubbard', 18, 340, 4.268562841153587)]:
        p = ROOT / case
        assert ast.literal_eval(configs[case]['Wavefunction_cutoff']) == cutoff
        frames = read(next(p.glob('*Trajectory.traj')), index=':')
        assert len(frames) == count
        np.testing.assert_allclose(frames[0].cell, initial.cell, atol=1e-12, rtol=0)
        np.testing.assert_allclose(frames[0].positions, initial.positions, atol=1e-12, rtol=0)
        a = read(next(p.glob('*Final.cif')))
        np.testing.assert_allclose(frames[-1].cell, a.cell, atol=1e-12, rtol=0)
        np.testing.assert_allclose(frames[-1].get_scaled_positions(wrap=True),
                                   a.get_scaled_positions(wrap=True), atol=1e-12, rtol=0)
        volumes, energies, fmax = [], [], []
        for atom in frames:
            cell_filter = FrechetCellFilter(atom, mask=[True, True, True, False, False, False])
            # The optimizer keeps the initial cell as its reference at every step.
            cell_filter.orig_cell = frames[0].cell.array.copy()
            volumes.append(atom.get_volume())
            energies.append(atom.get_potential_energy(force_consistent=True))
            fmax.append(np.linalg.norm(cell_filter.get_forces(), axis=1).max())
        volumes, energies, fmax = map(np.array, (volumes, energies, fmax))
        recorded = np.array([[float(v) for v in line.split()[1:]]
                             for line in records if line.split()[0] == case])
        np.testing.assert_array_equal(recorded[:, 0], np.arange(count))
        np.testing.assert_allclose(recorded[:, 1], energies, atol=5.1e-7, rtol=0)
        np.testing.assert_allclose(recorded[:, 2], fmax, atol=5.1e-7, rtol=0)
        assert fmax[-1] < .05
        values = load(case, '*XYYY.dat')
        long = load(case, '*Result-Band.dat')
        state = BandStructure.read(next(p.glob('*State.json')))
        assert values.shape == (40, 37) and state.reference == 0
        e = values[:, 1:]
        np.testing.assert_allclose(e, state.energies[0], atol=1e-12, rtol=0)
        np.testing.assert_allclose(e, long[:, 1].reshape(-1, 40).T, atol=1e-12, rtol=0)
        np.testing.assert_array_equal(long[:, 0].reshape(-1, 40), np.tile(values[:, 0], (36, 1)))
        x, special, labels = state.path.get_linear_kpoint_axis()
        kp = load(case, '*KPath.dat', usecols=[0, 1, 2])
        np.testing.assert_allclose(kp[:, 1], x, atol=1e-12, rtol=0)
        assert labels == list('ALMGAHKG')
        np.testing.assert_allclose(state.path.kpts[[15, 39]], 0, atol=1e-12)
        vbm, cbm = e[:, 17].max(), e[:, 18].min()
        gap = cbm - vbm
        np.testing.assert_allclose(gap, expected_gap, atol=1e-10, rtol=0)
        np.testing.assert_allclose(np.min(e[:, 18] - e[:, 17]), gap, atol=1e-9, rtol=0)
        dos, pd = load(case, '*Result-DOS.dat'), load(case, '*Result-PDOS.dat')
        raw = load(case, '*Raw-PDOS*', usecols=[0, *range(2, 16)]).reshape(4, 501, 15)
        assert dos.shape == (501, 2) and pd.shape == (501, 14)
        assert np.isfinite(dos).all() and np.isfinite(pd).all() and np.isfinite(raw).all()
        assert (np.diff(dos[:, 0]) > 0).all() and (dos[:, 1] >= 0).all()
        np.testing.assert_allclose(dos[:, 0], pd[:, 0], atol=1e-12, rtol=0)
        np.testing.assert_allclose(raw[:, :, 1], np.tile(pd[:, 0], (4, 1)), atol=1e-12, rtol=0)
        for left, right in [(pd[:, 2], pd[:, 3:6].sum(1)), (pd[:, 6], pd[:, 7:12].sum(1)),
                            (pd[:, -1], pd[:, [1, 2, 6, 12]].sum(1)), (raw[:, :, 2:].sum(0), pd[:, 1:])]:
            np.testing.assert_allclose(left, right, atol=1e-13, rtol=0)
        np.testing.assert_array_equal(raw[:, 0, 0], [1, 2, 3, 4])
        assert a.get_chemical_symbols() == ['Zn', 'O', 'Zn', 'O']
        zn_d, o_p = raw[[0, 2], :, 7].sum(0), raw[[1, 3], :, 3].sum(0)
        pressure = -np.mean(frames[-1].get_stress()[:3]) / GPa
        checks += [f'{case}_cutoff_eV {cutoff}', f'{case}_trajectory_frames {count}',
                   f'{case}_final_volume_A3 {volumes[-1]:.12f}',
                   f'{case}_volume_ratio {volumes[-1]/volumes[0]:.12f}',
                   f'{case}_free_energy_change_eV {energies[-1]-energies[0]:.12f}',
                   f'{case}_final_filter_fmax {fmax[-1]:.12f}', f'{case}_final_pressure_GPa {pressure:.12f}',
                   f'{case}_path_gap_eV {gap:.12f}', f'{case}_vbm_eV {vbm:.12f}',
                   f'{case}_cbm_eV {cbm:.12f}', f'{case}_stored_DOS_integral {np.trapezoid(dos[:,1],dos[:,0]):.12f}']
        np.savetxt(ROOT / f'{case}-relaxation-audit.dat', np.c_[np.arange(count), volumes, energies, fmax],
                   fmt='%.12e', header='step volume_A3 free_energy_eV filter_fmax_eV_per_A')
        np.savetxt(ROOT / f'{case}-orbital-audit.dat', np.c_[pd[:, 0]-vbm, zn_d, o_p],
                   fmt='%.12e', header='E_minus_own_path_VBM_eV Zn_d_states_per_eV_cell O_p_states_per_eV_cell')
        all_data[case] = dict(volumes=volumes, energies=energies, fmax=fmax,
                              e=e, x=x, special=special, vbm=vbm,
                              dos=dos, zn_d=zn_d, o_p=o_p, orbital_energy=pd[:, 0]-vbm, gap=gap)
    checks += ['controlled_U_comparison NO_cutoff_and_geometry_differ',
               'historical_Hubbard_structure VALIDATION_REQUIRED', 'checks PASS']
    (ROOT / 'checks.dat').write_text('\n'.join(checks)+'\n')
    colors = {'reference': '#234e70', 'hubbard': '#b34d2b'}
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.9), constrained_layout=True)
    for case, data in all_data.items():
        label = 'PBE, 1400 eV' if case == 'reference' else 'PBE+U, 340 eV (historical)'
        step = np.arange(len(data['volumes']))
        axes[0].plot(step, data['volumes']/data['volumes'][0], 'o-', ms=3, color=colors[case], label=label)
        axes[1].plot(step, data['energies']-data['energies'][0], 'o-', ms=3, color=colors[case])
        axes[2].semilogy(step, data['fmax'], 'o-', ms=3, color=colors[case])
    axes[0].set(xlabel='Optimizer step', ylabel='V / initial V', title='Different relaxed structures')
    axes[0].legend(fontsize=8)
    axes[1].set(xlabel='Optimizer step', ylabel='Free energy minus own initial value (eV)', title='Energy rise needs investigation')
    axes[2].axhline(.05, color='black', ls='--', lw=1, label='Requested 0.05 eV/Å')
    axes[2].set(xlabel='Optimizer step', ylabel='Cell-filter maximum force (eV/Å)', title='Stopping criterion is satisfied')
    axes[2].legend(fontsize=8)
    for ax in axes:
        ax.grid(alpha=.2)
    fig.savefig(ROOT / 'zno-gpaw-relaxation-audit.png', dpi=170)
    fig, axes = plt.subplots(2, 2, figsize=(10, 7.2), constrained_layout=True)
    for column, (case, data) in enumerate(all_data.items()):
        ax, pdax = axes[:, column]
        ax.plot(data['x'], data['e']-data['vbm'], color=colors[case], lw=.9)
        ax.axhline(0, color='black', lw=.6)
        ax.set(xticks=data['special'], xticklabels=['A','L','M','Γ','A','H','K','Γ'], ylim=(-12, 7),
               xlim=(data['x'][0], data['x'][-1]), ylabel='Energy minus own path VBM (eV)',
               title='PBE: recorded reference' if case == 'reference' else 'PBE+U: contracted cell; audit only')
        ax.text(.04, .94, f"Path gap = {data['gap']:.3f} eV", transform=ax.transAxes, va='top', fontsize=10,
                bbox={'facecolor':'white','alpha':.85,'edgecolor':'none'})
        energy = data['orbital_energy']
        pdax.plot(energy, data['zn_d'], label='Zn d (both Zn sites)', color='#67568c')
        pdax.plot(energy, data['o_p'], label='O p (both O sites)', color='#2e8674')
        pdax.set(xlim=(-12, 6), xlabel='Energy minus own path VBM (eV)', ylabel='Projected states/eV/cell')
        selected = (energy >= -12) & (energy <= 6)
        pdax.set_ylim(0, 1.12*max(data['zn_d'][selected].max(), data['o_p'][selected].max()))
        pdax.axvline(0, color='black', lw=.6)
        pdax.legend(fontsize=8)
        ax.grid(alpha=.15)
        pdax.grid(alpha=.15)
    fig.savefig(ROOT / 'zno-gpaw-bands-pdos.png', dpi=170)
    print('\n'.join(checks))


if __name__ == '__main__':
    main()

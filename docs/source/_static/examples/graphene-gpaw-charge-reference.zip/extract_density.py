# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.
"""Recreate density checks from the four original CUBEs, without GPAW.

Usage: python extract_density.py /path/to/Neutral /path/to/Charged
The original all-electron CUBEs are large and are not included in the archive.
Outputs are separately named *-regenerated.dat; bundled tables are retained.
"""
from pathlib import Path
import argparse
import hashlib
import numpy as np

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('neutral_dir', type=Path)
parser.add_argument('charged_dir', type=Path)
args = parser.parse_args()
source_hashes = dict(line.split('  ', 1)[::-1] for line in
                     (ROOT / 'density-source-sha256.txt').read_text().splitlines())
profiles = {}
rows = ['# Case DensityKind ElectronIntegral(1) MinDensity(e/bohr^3) MaxDensity(e/bohr^3) NegativeVoxels(1) NegativeIntegral(e)']
BOHR = 0.5291772105638411  # angstrom; conversion used for the archived profile
for case, directory in [('neutral', args.neutral_dir), ('charged', args.charged_dir)]:
    for kind in ('npseudo', 'nall'):
        name = 'graphene4x4withdefect-EDENSITY-GPAW-Result-All-electron_' + kind + '-Total.cube'
        path = directory / name
        with path.open('rb') as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == source_hashes[case + '/' + name]
        with path.open() as stream:
            header = [next(stream) for _ in range(6)]
            natoms = int(header[2].split()[0])
            assert natoms == 31
            for _ in range(natoms):
                next(stream)
            dims = [int(header[i].split()[0]) for i in (3, 4, 5)]
            assert all(d > 0 for d in dims)  # Archived coordinates use bohr.
            voxel = np.array([[float(v) for v in header[i].split()[1:4]] for i in (3, 4, 5)])
            a = np.fromstring(stream.read(), sep=' ').reshape(dims)
        assert np.isfinite(a).all()
        dv = abs(np.linalg.det(voxel))
        integral = float(a.sum() * dv)
        negative = float(a[a < 0].sum() * dv)
        rows.append(f'{case} {kind} {integral:.12g} {a.min():.12g} {a.max():.12g} {(a < 0).sum()} {negative:.12g}')
        if kind == 'nall':
            assert np.allclose(voxel[2, :2], 0) and np.allclose(voxel[:2, 2], 0)
            dz = voxel[2, 2] * BOHR
            z = (float(header[2].split()[3]) + np.arange(dims[2]) * voxel[2, 2]) * BOHR
            profiles[case] = np.column_stack([z, a.sum(axis=(0, 1)) * dv / dz])
neutral, charged = profiles['neutral'], profiles['charged']
assert np.array_equal(neutral[:, 0], charged[:, 0])
out = np.column_stack([neutral, charged[:, 1], charged[:, 1] - neutral[:, 1]])
expected = np.loadtxt(ROOT / 'planar-density.dat')
assert np.allclose(out, expected, rtol=1e-10, atol=1e-9)
np.savetxt(ROOT / 'planar-density-regenerated.dat', out,
           header='z(angstrom) Neutral_line_density(e/angstrom) Charged_line_density(e/angstrom) Charged_minus_neutral(e/angstrom)', fmt='%.12g')
(ROOT / 'density-checks-regenerated.dat').write_text('\n'.join(rows) + '\n')
print('\n'.join(rows))

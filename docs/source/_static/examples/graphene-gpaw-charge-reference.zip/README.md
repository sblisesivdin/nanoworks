# Neutral and +1 graphene vacancy reference data

Source: example-runs-Va5NDWGi/GPAW/graphene-neutral and graphene-charged,
28 October 2026. Reviewed 30 October 2026.
Nanoworks 27.2.0rc0, GPAW 26.7.0, ASE 3.29.0; eight MPI processes.
The exact source commit and PAW/basis package release were not recorded.

The two inputs differ only in Outdirname and Total_charge (0 versus +1).
Both use the same C31 vacancy CIF, LDA/LCAO dzp, 0.2 angstrom grid spacing,
Gamma-centred 4x4x1 k-points, Fermi-Dirac width 0.05 eV, tetrahedron DOS with
501 samples, no spin polarization, separate atomic relaxations at fixed cell.
Symmetry is preserved. These are constrained workflow examples, not verified
magnetic or structural ground states of an isolated vacancy.

## Plot and check without DFT

Install NumPy >=2 and Matplotlib, then run:

    python plot_graphene.py

Outputs: graphene-gpaw-charge.png, graphene-gpaw-charge-checks.png, checks.dat.
The script checks long/XYYY/State bands, KPath, finite/nonnegative electronic
tables, atom-to-aggregate PDOS and orbital sums. Both spectra use their own Ef;
there is no shared absolute potential or vacuum-level alignment.

## Density provenance and reproduction

planar-density.dat is derived from the original all-electron CUBEs by summing
xy voxels with their volume and dividing by the z step. Its full-cell sum
times dz yields 185.999486 and 184.999489 electrons; their difference is
-0.9999974 electrons. Positive charge removes one electron.
density-checks.dat records the original pseudo/all-electron checks.
density-source-sha256.txt identifies all four CUBEs; they remain in the original
run rather than being duplicated in this archive.

To regenerate the density profile and extended checks from those CUBEs:

    python extract_density.py /path/to/Neutral /path/to/Charged

This verifies the source hashes and writes separately named *-regenerated.dat
files, comparing the new profile against the bundled one. The original two
all-electron CUBEs total about 331 MB. No DFT calculation is run.

CUBE density units are electrons/bohr^3 and voxel vectors use bohr. Planar line
density units are electrons/angstrom. This difference includes ionic relaxation;
it is not a fixed-geometry hole map or atom-resolved charge partition.
Small negative reconstructed all-electron density values were retained, not
clipped. Local density interpretation needs reconstruction/grid convergence.

## Scientific limits

The saved DOS integrals differ substantially from the full band weights:
neutral 226.94 versus 248 states; charged 275.46 versus 246 states.
The coarse energy/k-grid sampling is not adequate for quantitative DOS amplitudes
or state counting. The fields and charged periodic electrostatics also need
vacuum and size convergence. Raw total energy and Ef differences do not give
charge-transition levels or work-function changes.

Files under data/ and the starting CIF preserve original bytes.
SHA256SUMS covers the distribution except itself; generated PNG/check files
are excluded from the archive and reproduced by the scripts.
Code and project data are distributed under LICENSE.md (MIT).
No third-party library source code is included.

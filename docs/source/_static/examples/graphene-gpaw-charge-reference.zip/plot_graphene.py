# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.
"""Check and plot the neutral/+1 graphene vacancy records without running DFT.

Requires NumPy >=2 and Matplotlib. Density profiles are derived from original
CUBEs, whose hashes are recorded separately; the large CUBEs are not bundled.
"""
from pathlib import Path
import ast
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
PREFIX = 'graphene4x4withdefect-'
records = {}
checks = []


def settings(path):
    values = {}
    for node in ast.parse(path.read_text()).body:
        if isinstance(node, ast.Assign):
            try:
                value = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                continue
            for target in node.targets:
                if isinstance(target, ast.Name):
                    values[target.id] = value
    return values


for case, nbands, charge in [('neutral', 124, 0), ('charged', 123, 1)]:
    data = ROOT / 'data' / case
    read = lambda suffix: np.loadtxt(data / (PREFIX + suffix), skiprows=1)
    bands = read('BAND-GPAW-Result-Band-XYYY.dat')
    long = read('BAND-GPAW-Result-Band.dat')
    dos = read('DOS-GPAW-Result-DOS.dat')
    pdos = read('DOS-GPAW-Result-PDOS.dat')
    raw = np.loadtxt(data / (PREFIX + 'DOS-GPAW-Result-Raw-PDOS-Each-Atom.dat'), dtype=str, skiprows=1)
    indices = raw[:, 0].astype(int)
    atoms = np.array([raw[indices == i, 2:].astype(float) for i in range(1, 32)])
    assert set(raw[:, 1]) == {'C'} and atoms.shape == (31, 501, 14)
    assert bands.shape == (40, nbands + 1) and dos.shape == (501, 2)
    assert np.array_equal(long[:, 0], np.tile(np.arange(40), nbands))
    assert np.array_equal(long[:, 1].reshape(nbands, 40).T, bands[:, 1:])
    assert all(np.isfinite(a).all() for a in (bands, long, dos, pdos, atoms))
    assert np.all(np.diff(dos[:, 0]) > 0) and np.all(dos[:, 1] >= 0)
    assert np.all(pdos[:, 1:] >= 0) and np.all(atoms[:, :, 1:] >= 0)
    assert np.array_equal(dos[:, 0], pdos[:, 0])
    assert all(np.array_equal(a[:, 0], dos[:, 0]) for a in atoms)
    assert np.allclose(atoms[:, :, 1:].sum(axis=0), pdos[:, 1:], atol=1e-11, rtol=0)
    for a in (pdos, *atoms):
        assert np.allclose(a[:, 2], a[:, 3:6].sum(axis=1), atol=1e-11, rtol=0)
        assert np.allclose(a[:, 6], a[:, 7:12].sum(axis=1), atol=1e-11, rtol=0)
        assert np.allclose(a[:, -1], a[:, [1, 2, 6, 12]].sum(axis=1), atol=1e-11, rtol=0)
    state = json.loads((data / (PREFIX + 'BAND-GPAW-Result-State.json')).read_text())
    shape, dtype, values = state['energies']['__ndarray__']
    assert shape == [1, 40, nbands] and state['reference'] == 0.0
    assert np.array_equal(np.array(values, dtype=dtype).reshape(shape)[0], bands[:, 1:])
    kpath = np.loadtxt(data / (PREFIX + 'BAND-GPAW-Result-KPath.dat'), dtype=str, skiprows=1)
    assert np.array_equal(kpath[:, 0].astype(int), np.arange(40))
    assert np.all(np.diff(kpath[:, 1].astype(float)) > 0)
    assert not np.any(kpath[:, 2].astype(int))
    assert list(kpath[kpath[:, 3] != '-', 3]) == ['G', 'K', 'M', 'G']
    config = settings(data / ('graphene-' + case + '.py'))
    assert config['Total_charge'] == charge and config['Spin_calc'] is False
    crossing = np.where((bands[:, 1:].min(0) < 0) & (bands[:, 1:].max(0) > 0))[0] + 1
    records[case] = dict(bands=bands, dos=dos, pdos=pdos, kpath=kpath, config=config)
    checks.extend([
        f'{case} DOS_at_Ef_interpolated(states/eV/cell) {np.interp(0, *dos.T):.12g}',
        f'{case} DOS_window_integral(states/cell) {np.trapezoid(dos[:, 1], dos[:, 0]):.12g}',
        f'{case} full_band_weight(states/cell) {2 * nbands}',
        f'{case} bands_straddling_Ef_1based(1) ' + ','.join(map(str, crossing)),
    ])
assert {key for key in records['neutral']['config']
        if records['neutral']['config'][key] != records['charged']['config'][key]} == {'Outdirname', 'Total_charge'}
assert np.array_equal(records['neutral']['kpath'], records['charged']['kpath'])

profile = np.loadtxt(ROOT / 'planar-density.dat')
assert profile.shape == (400, 4) and np.isfinite(profile).all()
assert np.allclose(profile[:, 3], profile[:, 2] - profile[:, 1], atol=1e-9, rtol=0)
dz = profile[1, 0] - profile[0, 0]
assert np.allclose(np.diff(profile[:, 0]), dz, atol=1e-10, rtol=0)
delta = float(profile[:, 3].sum() * dz)
assert abs(delta + 1) < 1e-4
checks.append(f'density_profile charged_minus_neutral_electrons(1) {delta:.12g}')
(ROOT / 'checks.dat').write_text('# Derived checks; input energy axes are separately relative to each case Ef.\n' + '\n'.join(checks) + '\n')

plt.rcParams.update({'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False})
colors = {'neutral': '#176b91', 'charged': '#b35b29'}
fig, axes = plt.subplots(1, 3, figsize=(11.5, 5.1), sharey=True,
                         gridspec_kw={'width_ratios': [1.2, 1.2, 1]})
for ax, case in zip(axes[:2], ('neutral', 'charged')):
    rec = records[case]
    x = rec['kpath'][:, 1].astype(float)
    for band in rec['bands'][:, 1:].T:
        ax.plot(x, band, color=colors[case], lw=.9)
    special = rec['kpath'][:, 3] != '-'
    ticks = x[special]
    for value in ticks:
        ax.axvline(value, color='0.85', lw=.7)
    ax.set(xticks=ticks, xticklabels=[r'$\Gamma$', 'K', 'M', r'$\Gamma$'],
           xlim=(x[0], x[-1]), ylim=(-2, 2), xlabel='Supercell wave-vector path',
           title='Neutral' if case == 'neutral' else '+1 charge (one electron removed)')
for case, rec in records.items():
    axes[2].plot(rec['dos'][:, 1], rec['dos'][:, 0], color=colors[case], label=case.capitalize())
axes[2].set(xlabel='DOS (states/eV/cell)', title='Tetrahedron DOS', xlim=(0, 70))
axes[2].legend(frameon=False, fontsize=9)
axes[0].set_ylabel(r'$E-E_F$ of each calculation (eV)')
for ax in axes:
    ax.axhline(0, color='0.3', ls='--', lw=.8)
fig.suptitle('Graphene vacancy | separately relaxed neutral and +1 cells')
fig.text(.5, .015, 'LDA/LCAO, non-spin-polarized; separate Fermi references, no common absolute energy alignment; unconverged DOS sampling.', ha='center', fontsize=9)
fig.tight_layout(rect=(0, .055, 1, .94))
fig.savefig(ROOT / 'graphene-gpaw-charge.png', dpi=180)
plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(11, 4.8))
for case, rec in records.items():
    p = rec['pdos']
    axes[0].plot(p[:, 0], p[:, 3], color=colors[case], label=case.capitalize() + r' $p_z$')
    axes[0].plot(p[:, 0], p[:, 4] + p[:, 5], color=colors[case], ls='--', label=case.capitalize() + r' $p_x+p_y$')
axes[0].axvline(0, color='0.3', ls=':', lw=.8)
peak = max(max(np.max(r['pdos'][abs(r['pdos'][:, 0]) <= 1, 3]),
               np.max(r['pdos'][abs(r['pdos'][:, 0]) <= 1, 4:6].sum(axis=1)))
           for r in records.values())
axes[0].set(xlim=(-1, 1), ylim=(0, 1.1 * peak), xlabel=r'$E-E_F$ of each calculation (eV)',
            ylabel='Projected states / (eV cell)', title='Orbital character near each Fermi level')
axes[0].legend(frameon=False, fontsize=8)
axes[1].plot(profile[:, 0], profile[:, 3], color='#705898')
axes[1].axhline(0, color='0.5', ls=':', lw=.8)
axes[1].set(xlim=(2, 8), xlabel=r'$z$ (angstrom)', ylabel=r'$\lambda_{+1}(z)-\lambda_0(z)$ (electrons/angstrom)',
            title=f'Plane-integrated all-electron density difference\nFull-cell integral = {delta:.6f} electrons')
fig.suptitle('Graphene vacancy | orbital projections and electron-count check')
fig.text(.5, .015, 'Density difference includes ionic relaxation; it is not a fixed-geometry hole density or an atom-resolved charge partition.', ha='center', fontsize=9)
fig.tight_layout(rect=(0, .055, 1, .94))
fig.savefig(ROOT / 'graphene-gpaw-charge-checks.png', dpi=180)
plt.close(fig)
print('\n'.join(checks))

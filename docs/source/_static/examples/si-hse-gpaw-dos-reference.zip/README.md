# Si HSE06 ground-state and DOS reference

Source: example-runs-Va5NDWGi/GPAW/si-hse, 28 October 2026. Nanoworks 27.2.0rc0, GPAW 26.7.0, ASE 3.29.0, eight processes. The exact run source SHA and PAW package release were not recorded. Active input and starting CIF match the inspected repository.

The original input retains Band_calc=True. For the illustrated GPAW ground-state/DOS tutorial, run it with -s Band_calc=False. The legacy path stage restarted SCF on equally weighted path points; it is not a validated dispersion of the original uniform-mesh hybrid state. Its plots and band tables are deliberately not included as material reference data. No solver fix or replacement band calculation is claimed.

Original inputs, CIFs and DOS/PDOS tables are preserved in data/. ground-eigenvalues.dat is derived from the original GPW and contains four irreducible k-points, eight bands, weights and occupations. The original GPW remains in Drive; its SHA256 is recorded in source-gpw-sha256.txt.

Optional redraw: with numpy>=2 and matplotlib installed, run python plot_si_hse.py. This checks Gaussian DOS reconstruction, occupations and PDOS identities, then recreates two PNGs and checks.dat without DFT. Optional source verification: with ASE installed, run python extract_ground.py /path/to/original.gpw. It verifies the GPW hash and writes a separately named regenerated table.

Settings are for a short demonstration, not converged material constants. Energies are relative to the ground-state Fermi reference. Occupation width and DOS Gaussian width are distinct controls even though both are 0.2 eV here.

SHA256SUMS covers all distributed files except itself. MIT terms: LICENSE.md.

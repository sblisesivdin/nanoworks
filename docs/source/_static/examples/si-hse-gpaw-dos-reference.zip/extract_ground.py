# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.
"""Re-extract the audit table from the original GPW using ASE, without DFT."""
from pathlib import Path
import hashlib
import sys
import numpy as np
from ase.io.ulm import Reader

root=Path(__file__).resolve().parent
source=Path(sys.argv[1])
assert hashlib.sha256(source.read_bytes()).hexdigest()==(root/'source-gpw-sha256.txt').read_text().split()[0]
with Reader(source) as r:
    e=r.wave_functions.eigenvalues[0]
    o=r.wave_functions.occupations[0]
    w=r.wave_functions.kpts.weights
    k=r.wave_functions.kpts.ibzkpts
    ef=float(r.wave_functions.fermi_levels[0])
    rows=[[i,j,*k[i],w[i],e[i,j],e[i,j]-ef,o[i,j]]
          for i in range(e.shape[0]) for j in range(e.shape[1])]
np.savetxt(root/'ground-eigenvalues-regenerated.dat',rows,
           header='KIndex(1) BandIndex(1) k1(1) k2(1) k3(1) Weight(1) Eigenvalue(eV) E_minus_Ef(eV) Occupation_per_spin(1)',fmt='%.17g')
assert np.array_equal(np.array(rows),np.loadtxt(root/'ground-eigenvalues.dat'))
print('Original GPW hash and extracted ground-state table verified.')

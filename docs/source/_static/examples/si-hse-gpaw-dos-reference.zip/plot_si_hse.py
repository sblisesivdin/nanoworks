# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.
"""Verify the recorded ground-state DOS; do not use the legacy path-SCF bands."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
PREFIX = 'Si_mp-149_primitive-'
dos = np.loadtxt(DATA / (PREFIX + 'DOS-GPAW-Result-DOS.dat'), skiprows=1)
pdos = np.loadtxt(DATA / (PREFIX + 'DOS-GPAW-Result-PDOS.dat'), skiprows=1)
raw = np.loadtxt(DATA / (PREFIX + 'DOS-GPAW-Result-Raw-PDOS-Each-Atom.dat'), skiprows=1, dtype=str)
atoms = np.array([raw[raw[:,0].astype(int)==i, 2:].astype(float) for i in (1,2)])
assert dos.shape == (301,2) and atoms.shape == (2,301,14)
assert set(raw[:,1]) == {'Si'} and pdos.shape == (301,14)
assert np.all(np.diff(dos[:,0]) > 0)
assert all(np.array_equal(a[:,0],dos[:,0]) for a in (pdos,*atoms))
assert all(np.isfinite(a).all() for a in (dos,pdos,atoms))
assert np.all(dos[:,1]>=0) and np.all(pdos[:,1:]>=0) and np.all(atoms[:,:,1:]>=0)
assert np.allclose(atoms[:,:,1:].sum(0),pdos[:,1:],atol=1e-11,rtol=0)
for a in (pdos,*atoms):
    assert np.allclose(a[:,2],a[:,3:6].sum(1),atol=1e-11,rtol=0)
    assert np.allclose(a[:,6],a[:,7:12].sum(1),atol=1e-11,rtol=0)
    assert np.allclose(a[:,-1],a[:,[1,2,6,12]].sum(1),atol=1e-11,rtol=0)
g = np.loadtxt(ROOT/'ground-eigenvalues.dat')
assert g.shape == (32,9) and np.isfinite(g).all()
assert np.array_equal(g[:,0],np.repeat(np.arange(4),8))
assert np.array_equal(g[:,1],np.tile(np.arange(8),4))
e = g[:,7].reshape(4,8)
w = g[::8,5]
assert np.isclose(w.sum(),1,atol=1e-14)
ne = float(2*np.sum(g[:,5]*g[:,8]))
assert abs(ne-8)<1e-12
width = .2
reconstructed = (2*w[:,None,None]*np.exp(-((dos[:,0][None,None,:]-e[:,:,None])/width)**2)
                 /(width*np.sqrt(np.pi))).sum((0,1))
error = float(abs(reconstructed-dos[:,1]).max())
assert error < 1e-11
gap = float(e[:,4].min()-e[:,3].max())
checks = [f'ground_mesh_gap(eV) {gap:.12g}',
          f'occupation_electrons(1) {ne:.12g}',
          f'Gaussian_DOS_reconstruction_max_error(states/eV/cell) {error:.12g}',
          f'DOS_window_integral(states/cell) {np.trapezoid(dos[:,1],dos[:,0]):.12g}',
          'full_band_weight(states/cell) 16',
          f'DOS_at_Ef_interpolated(states/eV/cell) {np.interp(0,*dos.T):.12g}']
(ROOT/'checks.dat').write_text('# Ground-state checks only; no path-SCF band result is endorsed.\n'+'\n'.join(checks)+'\n')
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig, (ax,dx) = plt.subplots(1,2,figsize=(9.7,5),sharey=True,gridspec_kw={'width_ratios':[1.2,1]})
for i in range(4):
    ax.scatter(np.full(8,i),e[i],s=24,color='#176b91')
ax.set(xticks=range(4),xticklabels=['IBZ 0 (Gamma)','IBZ 1','IBZ 2','IBZ 3'],
       xlabel='Four irreducible ground-state k-points',ylabel=r'$E-E_F$ of ground state (eV)',
       title='Discrete eigenvalues on the 3 x 3 x 3 mesh',ylim=(-4,4))
for label in ax.get_xticklabels():label.set_rotation(15)
dx.plot(dos[:,1],dos[:,0],color='#176b91',label='Exported DOS')
dx.plot(reconstructed,dos[:,0],color='#b35b29',ls='--',label='Weighted Gaussian sum')
dx.set(xlim=(0,1.1*dos[abs(dos[:,0])<=4,1].max()),xlabel='DOS (states/eV/cell)',title='Ground-state DOS | width 0.2 eV')
dx.legend(frameon=False,fontsize=8)
for a in (ax,dx):a.axhline(0,color='.4',ls=':',lw=.8)
fig.text(.5,.02,'HSE06 demonstration settings; discrete mesh eigenvalues are not a band dispersion or a converged fundamental-gap estimate.',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.06,1,1));fig.savefig(ROOT/'si-hse-gpaw-dos.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(8,4.5))
for col,label,style in [(1,'Si s',':'),(2,'Si p','-'),(6,'Si d','--')]:
    ax.plot(pdos[:,0],pdos[:,col],ls=style,label=label)
visible = abs(pdos[:,0])<=4
ax.set(xlim=(-4,4),ylim=(0,1.1*pdos[visible][:,[1,2,6]].max()),
       xlabel=r'$E-E_F$ of ground state (eV)',ylabel='Projected states / (eV cell)',
       title='Si orbital projections | sum over both atoms')
ax.axvline(0,color='.4',ls=':',lw=.8);ax.legend(frameon=False)
fig.text(.5,.02,'Gaussian-broadened projector weights; not a complete partition of total DOS. No legacy path-SCF bands are shown.',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.06,1,1));fig.savefig(ROOT/'si-hse-gpaw-pdos.png',dpi=180);plt.close(fig)
print('\n'.join(checks))

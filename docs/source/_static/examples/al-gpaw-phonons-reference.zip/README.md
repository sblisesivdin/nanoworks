# Al GPAW phonon reference data

Recorded source: example-runs-Va5NDWGi/GPAW/al-phonon, reviewed 2026-10-29.
Nanoworks 27.2.0rc0, GPAW 26.7.0, ASE 3.29.0, Phonopy 4.8.6, 8 MPI processes.
Exact run source commit and PAW dataset release were not recorded.

See the Nanoworks tutorial `examples/al-gpaw-phonons` for settings, commands,
interpretation and limitations. These are finite-supercell example results,
not converged reference values. All data files in data/ are original bytes.
The final CIF is written in P1 representation but describes the fcc structure.

## Replot without running DFT

Install numpy>=2.0, matplotlib and PyYAML in an analysis environment, then run:

    python plot_phonons.py

Outputs: al-gpaw-phonons.png, al-gpaw-thermal.png, checks.json,
and thermal-without-gamma.dat. Figures are regenerated, not included in this ZIP.
The script checks finite data, weighted mesh size, DAT/YAML agreement and
independent harmonic F/S/Cv sums using Phonopy 4.8.6 physical constants.

The thermal curves retain the archived output. The separate comparison table
excludes all three Gamma translations in a weighted harmonic sum using the
exported, rounded mesh frequencies. It is not a DFT rerun or mesh extrapolation.
One tiny positive Gamma frequency enters the archived sums and biases F at
1000 K by approximately -0.01777 kJ/mol. Other low-frequency modes are preserved.

## Retained source data

Input Python and CIF, relaxed CIF, compact force constants, displaced forces,
Phonopy YAML, band DAT/YAML, DOS DAT, weighted mesh DAT, thermal DAT/YAML.
SHA256SUMS covers inputs, raw results, this README, plot script and license.
No electronic wavefunction files are needed for these plots.
Code and project results are distributed under LICENSE.md (MIT).
No third-party library source code is included.

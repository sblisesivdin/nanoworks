# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.
"""Plot archived Al results and independently check weighted harmonic sums.

Run from any directory: python plot_phonons.py. No DFT engine is used.
Dependencies: numpy, matplotlib, PyYAML.
"""
from pathlib import Path
import json
import numpy as np
import yaml
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
PREFIX = 'Al_mp-134_primitive-PHONON-GPAW-Result-'


def table(suffix):
    return np.loadtxt(DATA / (PREFIX + suffix + '.dat'), skiprows=1)


band = table('Band')
dos = table('DOS')
mesh = table('Mesh-THz')
thermal = table('Thermal-Properties')
byaml = yaml.safe_load((DATA / (PREFIX + 'Band.yaml')).read_text())
tyaml = yaml.safe_load((DATA / (PREFIX + 'Thermal-Properties.yaml')).read_text())
assert all(np.isfinite(a).all() for a in (band, dos, mesh, thermal))
assert mesh[:, 3].sum() == 21 ** 3
assert np.all(dos[:, 1] >= 0)
raw_band = np.array([[r['distance']] + [v['frequency'] for v in r['band']]
                     for r in byaml['phonon']])
assert np.max(np.abs(raw_band - band)) < 5.1e-7
raw_thermal = np.array([[r[k] for k in ('temperature', 'free_energy', 'entropy', 'heat_capacity')]
                        for r in tyaml['thermal_properties']])
assert np.max(np.abs(raw_thermal - thermal)) < 1e-6

# Numerical values from Phonopy v4.8.6 physical_units.py; no library code copied.
# https://github.com/phonopy/phonopy/blob/v4.8.6/phonopy/physical_units.py
H = 0.00413566733  # eV / THz (h * frequency, not hbar * frequency)
KB = 1.3806504e-23 / 1.60217733e-19  # eV / K
CONV = 1.60217733e-19 * 6.02214179e23 / 1000  # kJ/mol / eV
R = KB * CONV * 1000
frequencies = mesh[:, 4:]
weights = np.broadcast_to(mesh[:, 3, None], frequencies.shape)
gamma = np.linalg.norm(mesh[:, :3], axis=1) < 1e-9
positive = frequencies > 0


def harmonic(mask):
    """F in kJ/mol, S and Cv in J/(mol K), per one-atom primitive cell."""
    energy = frequencies[mask] * H
    w = weights[mask] / mesh[:, 3].sum()
    zpe = np.sum(w * energy / 2) * CONV
    rows = []
    for temp in thermal[:, 0]:
        if temp == 0:
            rows.append([temp, zpe, 0., 0.])
            continue
        x = energy / (KB * temp)
        logterm = np.log(-np.expm1(-x))
        occupation = np.exp(-x) / (-np.expm1(-x))
        free = np.sum(w * (energy / 2 + KB * temp * logterm)) * CONV
        entropy = np.sum(w * KB * (x * occupation - logterm)) * CONV * 1000
        cv = np.sum(w * KB * x ** 2 * np.exp(-x) / (-np.expm1(-x)) ** 2) * CONV * 1000
        rows.append([temp, free, entropy, cv])
    return np.array(rows)


reconstructed = harmonic(positive)
# The DAT rounds the tiny positive Gamma frequency. Allow its corresponding
# log(frequency) effect on F and S; the archived YAML remains authoritative.
assert np.max(np.abs(reconstructed[:, 1] - thermal[:, 1])) < 1e-5
assert np.max(np.abs(reconstructed[:, 2] - thermal[:, 2])) < 1e-5
assert np.max(np.abs(reconstructed[:, 3] - thermal[:, 3])) < 1e-6
without_gamma = harmonic(positive & ~gamma[:, None])
np.savetxt(ROOT / 'thermal-without-gamma.dat', without_gamma,
           header='T(K) F(kJ/mol) S(J/mol/K) Cv(J/mol/K); independently reconstructed, Gamma excluded')
checks = {
    'dos_integral_modes_per_primitive_cell': float(np.trapezoid(dos[:, 1], dos[:, 0])),
    'mesh_weight_sum': float(mesh[:, 3].sum()),
    'non_gamma_minimum_thz': float(frequencies[~gamma].min()),
    'band_maximum_thz': float(band[:, 1:].max()),
    'maximum_reconstruction_errors_F_S_Cv': np.max(abs(reconstructed[:, 1:] - thermal[:, 1:]), axis=0).tolist(),
    'gamma_effect_at_1000K_F_S_Cv': (thermal[-1, 1:] - without_gamma[-1, 1:]).tolist(),
}
(ROOT / 'checks.json').write_text(json.dumps(checks, indent=2) + '\n')

plt.rcParams.update({'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False})
fig, (ax, dx) = plt.subplots(1, 2, figsize=(10, 4.8), sharey=True,
                             gridspec_kw={'width_ratios': [3, 1]})
starts = np.r_[0, np.cumsum(byaml['segment_nqpoint'])]
ticks = [raw_band[0, 0]] + [raw_band[i - 1, 0] for i in starts[1:]]
for start, end in zip(starts[:-1], starts[1:]):
    for mode in range(3):
        ax.plot(raw_band[start:end, 0], raw_band[start:end, mode + 1], color='#176b91', lw=1.7)
for value in ticks:
    ax.axvline(value, color='0.85', lw=.8)
ax.set(xticks=ticks, xticklabels=[r'$\Gamma$', 'X', 'K', r'$\Gamma$', 'L'],
       ylabel='Frequency (THz)', xlabel='Wave-vector path', xlim=(ticks[0], ticks[-1]), ylim=(-.25, 10))
dx.plot(dos[:, 1], dos[:, 0], color='#ae4c20', lw=1.7)
dx.set(xlabel=r'DOS (THz$^{-1}$ / cell)', xlim=(0, 1))
for axis in (ax, dx):
    axis.axhline(0, color='0.5', ls=':', lw=.8)
fig.suptitle('Al | GPAW/PBE phonons: three acoustic branches')
fig.text(.5, .015, 'Recorded 2 x 2 x 2 supercell; convergence with supercell and force settings remains to be established.', ha='center', fontsize=9)
fig.tight_layout(rect=(0, .05, 1, .94))
fig.savefig(ROOT / 'al-gpaw-phonons.png', dpi=180)
plt.close(fig)

fig, axes = plt.subplots(1, 3, figsize=(12, 4.4))
labels = ['Vibrational F (kJ/mol)', 'Entropy (J/mol/K)', r'$C_V$ (J/mol/K)']
for i, ax in enumerate(axes, 1):
    ax.plot(thermal[:, 0], thermal[:, i], color='#176b91', lw=2, label='Archived output')
    ax.set(xlabel='Temperature (K)', ylabel=labels[i - 1], xlim=(0, 1000))
    ax.grid(alpha=.15)
axes[2].axhline(3 * R, color='#ae4c20', ls='--', lw=1.2, label=r'$3R$')
axes[2].legend(frameon=False, fontsize=9)
fig.suptitle('Al | harmonic vibrational thermodynamics at fixed volume')
fig.text(.5, .015, 'Raw output retained: one near-zero Gamma mode enters the sums. No electronic or anharmonic contributions.', ha='center', fontsize=9)
fig.tight_layout(rect=(0, .05, 1, .94))
fig.savefig(ROOT / 'al-gpaw-thermal.png', dpi=180)
plt.close(fig)
print(json.dumps(checks, indent=2))

# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.

"""Audit recorded TiC stresses; requires NumPy, Matplotlib and ASE, not GPAW."""
from pathlib import Path
import hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ase.io import read
from ase.units import GPa
from ase.stress import voigt_6_to_full_3x3_stress as full

ROOT = Path(__file__).resolve().parent


def voigt(t):
    """Engineering strain order xx yy zz yz xz xy."""
    return np.array([t[0, 0], t[1, 1], t[2, 2],
                     2*t[1, 2], 2*t[0, 2], 2*t[0, 1]])


def cubic(e):
    m = np.zeros((6, 3))
    for i in range(3):
        m[i, 0] = e[i]
        m[i, 1] = sum(e[:3]) - e[i]
    m[3:, 2] = e[3:]
    return m


def fit(x, y, keep):
    m = np.concatenate([cubic(e) for e in x[keep]])
    b, _, rank, _ = np.linalg.lstsq(m, y[keep].ravel(), rcond=None)
    assert rank == 3
    return b, np.sqrt(np.mean((m @ b - y[keep].ravel())**2))


def main():
    for line in (ROOT / 'SOURCE-SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    frames = read(ROOT / 'TiC_primitive_geooptimized-ELASTIC-GPAW-Result-Elastic-deformations.traj', index=':')
    assert len(frames) == 30
    ref = frames[2]
    a = ref.cell.array
    canonical = np.linalg.norm(a[0]) / np.sqrt(2) * np.array([[0, 1, 1], [1, 0, 1], [1, 1, 0]])
    rotation = np.linalg.solve(canonical, a)  # row-vector crystal -> lab
    np.testing.assert_allclose(rotation @ rotation.T, np.eye(3), atol=1e-12)
    np.testing.assert_allclose(np.linalg.det(rotation), 1, atol=1e-12)
    x, y, xc, yc = [], [], [], []
    s0 = ref.get_stress() / GPa
    for atom in frames:
        f = np.linalg.solve(a, atom.cell.array)
        e = (f + f.T) / 2 - np.eye(3)
        ds = atom.get_stress() / GPa - s0
        x.append(voigt(e))
        y.append(ds)
        xc.append(voigt(rotation @ e @ rotation.T))
        sc = rotation @ full(ds) @ rotation.T
        yc.append([sc[0, 0], sc[1, 1], sc[2, 2], sc[1, 2], sc[0, 2], sc[0, 1]])
        np.testing.assert_allclose(atom.get_scaled_positions(), ref.get_scaled_positions(), atol=1e-12)
    x, y, xc, yc = map(np.array, (x, y, xc, yc))
    for start in range(0, 30, 5):
        e = x[start:start+5]
        active = np.argmax(np.max(abs(e), axis=0))
        amplitude = .01 if active < 3 else .02
        np.testing.assert_allclose(e[:, active], np.linspace(-amplitude, amplitude, 5), atol=1e-12)
        np.testing.assert_allclose(np.delete(e, active, axis=1), 0, atol=1e-12)
    all_points = np.ones(30, dtype=bool)
    inner = np.tile([False, True, True, True, False], 6)
    b_lab, rms_lab = fit(x, y, all_points)
    b_crystal, rms_crystal = fit(xc, yc, all_points)
    b_inner, rms_inner = fit(xc, yc, inner)
    pressure = -np.mean(s0[:3])
    correction = np.array([-pressure, pressure, -pressure])
    c_lab, c_crystal, c_inner = [b - correction for b in (b_lab, b_crystal, b_inner)]
    np.testing.assert_allclose(c_lab, [486.91569178, 136.65878046, 185.99409630], atol=1e-7)
    np.testing.assert_allclose(c_crystal, [518.22421112, 121.00452078, 170.30432080], atol=1e-7)
    c_full = np.linalg.lstsq(x, y, rcond=None)[0].T
    np.savetxt(ROOT / 'strain-stress.dat', np.c_[x, y], fmt='%.12e',
               header='engineering_strain_xx yy zz yz xz xy; delta_stress_GPa_xx yy zz yz xz xy')
    np.savetxt(ROOT / 'crystal-to-lab.dat', rotation, fmt='%.12e', header='row-vector rotation; A_crystal @ R = A_lab')
    np.savetxt(ROOT / 'lab-response.dat', c_full, fmt='%.12e', header='unconstrained stress/engineering-strain slopes (GPa); xx yy zz yz xz xy')
    rows = [f'frames {len(frames)}', f'pressure_GPa {pressure:.12f}',
            'archived_projection_C_GPa ' + ' '.join(f'{v:.8f}' for v in c_lab),
            'rotated_diagnostic_C_GPa ' + ' '.join(f'{v:.8f}' for v in c_crystal),
            'inner_window_diagnostic_C_GPa ' + ' '.join(f'{v:.8f}' for v in c_inner),
            f'lab_cubic_stress_RMS_GPa {rms_lab:.12f}',
            f'crystal_cubic_stress_RMS_GPa {rms_crystal:.12f}',
            f'inner_crystal_stress_RMS_GPa {rms_inner:.12f}',
            f'unconstrained_lab_stress_RMS_GPa {np.sqrt(np.mean((x @ c_full.T-y)**2)):.12f}']
    (ROOT / 'checks.dat').write_text('\n'.join(rows) + '\n')
    fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.1), constrained_layout=True)
    ax = axes[0]
    ax.plot(x[:5, 0]*100, y[:5, 3], 'o', color='#234e70', label='Recorded Cartesian stresses')
    ax.plot(x[:5, 0]*100, x[:5] @ c_full[3], color='#234e70', label='Full Cartesian linear fit')
    ax.axhline(0, color='#b14b36', ls='--', label='Unrotated cubic constraint')
    ax.set(xlabel='Cartesian strain xx (%)', ylabel='Change in stress yz (GPa)', title='A coupling suppressed by the archived fit')
    ax.legend(fontsize=8)
    ax.grid(alpha=.2)
    ax = axes[1]
    positions = np.arange(3)
    ax.bar(positions-.18, c_lab, .36, color='#b14b36', label='Archived projection (reproduced)')
    ax.bar(positions+.18, c_crystal, .36, color='#234e70', label='Rotated postprocessing diagnostic')
    ax.set(xticks=positions, xticklabels=['C11', 'C12', 'C44'], ylabel='GPa', title='Frame choice changes the fitted constants')
    ax.legend(fontsize=8)
    fig.savefig(ROOT / 'tic-gpaw-elastic-audit.png', dpi=170)
    print('\n'.join(rows))


if __name__ == '__main__':
    main()

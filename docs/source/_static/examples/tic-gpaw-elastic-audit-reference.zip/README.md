# TiC GPAW repeat: deformation-frame audit

Source and timing: provenance.json. Original inputs, final CIF, trajectory,
printed summary and electronic data retain their source bytes. Machine-specific
logs and the large GPW are not redistributed; LOG-SHA256SUMS identifies inspected
logs. SOURCE-SHA256SUMS covers original files; SHA256SUMS covers the whole package
except itself. LICENSE.md contains the project license.

Run `python plot_elastic_audit.py` with NumPy, Matplotlib and ASE. No GPAW or
Elastic installation is needed. It verifies source hashes and all 30 frames,
fits the archived unrotated cubic projection, rotates strain and stress to cubic
axes and compares all/inner strain windows. It generates derived strain-stress.dat,
crystal-to-lab.dat, lab-response.dat, checks.dat and tic-gpaw-elastic-audit.png.
The canonical fcc row cell is a/2 * [[0,1,1],[1,0,1],[1,1,0]], with
A_crystal @ R = A_lab. Stress components are xx yy zz yz xz xy; strain uses
the same order with engineering shear (twice the tensor off-diagonal).

The original cubic summary is invalid as a crystal-axis material prediction.
Rotation gives diagnostic C11/C12/C44 = 518.22421/121.00452/170.30432 GPa;
the original unrotated projection is 486.91569/136.65878/185.99410 GPa.
Both use Elastic's hydrostatic pressure correction. Rotated values are not
replacement production results. Cutoff, mesh and stress convergence, internal
relaxation and finite-deformation definitions require separate validation.
The current GPAW backend still needs an orientation-aware fit; use
`-s Elastic_calc=False` for the tutorial's electronic calculation meanwhile.

Run `python check_electronic.py` for long/XYYY/State band agreement, PDOS
orbital and atom sums, and a finite DOS at Ef. State and band tables are already
Ef-relative (State reference is 0 eV). Four sampled bands span Ef and
DOS(Ef) = 0.295223420880 states/eV/two-atom primitive cell. PDOS is a projection,
not an exact total-DOS sum rule.

Independent comparison with the historical reference ZIP found maximum absolute
band-energy difference 2.41e-11 eV, DOS difference 2.62e-8 states/eV/cell,
PDOS difference 1.59e-7 states/eV/cell, KPath distance difference 2.67e-14 /angstrom,
and cell/position differences below 1.60e-14 angstrom. The input and printed
elastic summary are byte-identical. These are repeated settings, not convergence
tests. The historical archive and its figure are retained unchanged.

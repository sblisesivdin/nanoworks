# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.

"""Check repeat DATs and band state using NumPy and ASE."""
from pathlib import Path
import hashlib
import numpy as np
from ase.spectrum.band_structure import BandStructure

root = Path(__file__).resolve().parent
for line in (root / 'SOURCE-SHA256SUMS').read_text().splitlines():
    digest, name = line.split('  ', 1)
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name


def load(pattern):
    return np.loadtxt(next(root.glob(pattern)), skiprows=1)


b = load('*Band-XYYY.dat')
long = load('*Result-Band.dat')
state = BandStructure.read(next(root.glob('*State.json')))
np.testing.assert_allclose(long[:, 1].reshape(-1, 40).T, b[:, 1:], atol=1e-12, rtol=0)
np.testing.assert_allclose(state.energies[0] - state.reference, b[:, 1:], atol=1e-12, rtol=0)
np.testing.assert_array_equal(long[:, 0].reshape(-1, 40), np.tile(b[:, 0], (16, 1)))
pd = load('*Result-PDOS.dat')
dos = load('*Result-DOS.dat')
np.testing.assert_allclose(pd[:, 0], dos[:, 0], atol=1e-12, rtol=0)
np.testing.assert_allclose(pd[:, 2], pd[:, 3:6].sum(axis=1), atol=1e-12, rtol=0)
np.testing.assert_allclose(pd[:, 6], pd[:, 7:12].sum(axis=1), atol=1e-12, rtol=0)
np.testing.assert_allclose(pd[:, -1], pd[:, [1, 2, 6, 12]].sum(axis=1), atol=1e-12, rtol=0)
raw = np.loadtxt(next(root.glob('*Raw-PDOS-Each-Atom.dat')), skiprows=1, usecols=[0, *range(2, 16)])
np.testing.assert_allclose(raw[:, 1:].reshape(2, 301, 14).sum(axis=0)[:, 1:], pd[:, 1:], atol=1e-12, rtol=0)
assert np.all(np.isfinite(b)) and np.all(np.isfinite(pd)) and np.all(np.isfinite(dos))
assert np.all(np.diff(dos[:, 0]) > 0)
crossings = np.sum(np.any(b[:, 1:] < 0, axis=0) & np.any(b[:, 1:] > 0, axis=0))
assert crossings > 0
value = np.interp(0, dos[:, 0], dos[:, 1])
assert abs(value - .2952234208804174) < 1e-12
text = f'band_shape 40 16\nbands_spanning_Ef {crossings}\nDOS_at_Ef_states_per_eV_cell {value:.12f}\nchecks PASS\n'
(root / 'electronic-checks.dat').write_text(text)
print(text, end='')

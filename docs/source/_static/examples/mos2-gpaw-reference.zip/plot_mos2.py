# SPDX-FileCopyrightText: Sefer Bora Lisesivdin and Beyza Lisesivdin
# SPDX-License-Identifier: MIT
# See LICENSE.md in the project root for license terms.
"""Verify recorded bulk MoS2 spectral exports and redraw two figures.

Requires NumPy >=2 and Matplotlib; does not run DFT or require a GPW file.
"""
from pathlib import Path
import json
import re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
PREFIX = 'Bulk_MoS2-'


def read(suffix):
    return np.loadtxt(DATA / (PREFIX + suffix), skiprows=1)


bands = read('BAND-GPAW-Result-Band-XYYY.dat')
long = read('BAND-GPAW-Result-Band.dat')
dos = read('DOS-GPAW-Result-DOS.dat')
pdos = read('DOS-GPAW-Result-PDOS.dat')
raw = np.loadtxt(DATA / (PREFIX + 'DOS-GPAW-Result-Raw-PDOS-Each-Atom.dat'),
                 skiprows=1, dtype=str)
atoms = np.array([raw[raw[:, 0].astype(int) == i, 2:].astype(float)
                  for i in range(1, 7)])
assert bands.shape == (61, 53) and dos.shape == (501, 2)
assert pdos.shape == (501, 14) and atoms.shape == (6, 501, 14)
assert [set(raw[raw[:, 0].astype(int) == i, 1]) for i in range(1, 7)] == [
    {'Mo'}, {'Mo'}, {'S'}, {'S'}, {'S'}, {'S'}]
assert np.array_equal(bands[:, 0], np.arange(61))
assert np.array_equal(long[:, 0], np.tile(np.arange(61), 52))
assert np.array_equal(long[:, 1].reshape(52, 61).T, bands[:, 1:])
state = json.loads((DATA / (PREFIX + 'BAND-GPAW-Result-State.json')).read_text())
shape, dtype, values = state['energies']['__ndarray__']
assert shape == [1, 61, 52] and state['reference'] == 0
assert np.array_equal(np.array(values, dtype=dtype).reshape(shape)[0], bands[:, 1:])
kp = np.loadtxt(DATA / (PREFIX + 'BAND-GPAW-Result-KPath.dat'), skiprows=1, dtype=str)
x = kp[:, 1].astype(float)
assert np.array_equal(kp[:, 0].astype(int), np.arange(61))
assert np.all(np.diff(x) > 0) and not np.any(kp[:, 2].astype(int))
assert list(kp[kp[:, 3] != '-', 3]) == ['G', 'M', 'K', 'G']
assert np.array_equal(dos[:, 0], pdos[:, 0])
assert all(np.array_equal(a[:, 0], dos[:, 0]) for a in atoms)
assert np.all(np.diff(dos[:, 0]) > 0)
assert all(np.isfinite(a).all() for a in (bands, long, dos, pdos, atoms))
assert np.all(dos[:, 1] >= 0) and np.all(pdos[:, 1:] >= 0)
assert np.all(atoms[:, :, 1:] >= 0)
atom_error = np.max(abs(atoms[:, :, 1:].sum(0) - pdos[:, 1:]))
assert atom_error < 1e-10
for a in (pdos, *atoms):
    assert np.allclose(a[:, 2], a[:, 3:6].sum(1), atol=1e-10, rtol=0)
    assert np.allclose(a[:, 6], a[:, 7:12].sum(1), atol=1e-10, rtol=0)
    assert np.allclose(a[:, -1], a[:, [1, 2, 6, 12]].sum(1), atol=1e-10, rtol=0)

# 52 occupied valence electrons, hence bands 26 and 27 bracket the gap.
v, c = bands[:, 26], bands[:, 27]
gap = c.min() - v.max()
direct = c - v
assert gap > 0 and not np.any((bands[:, 1:].min(0) < 0) & (bands[:, 1:].max(0) > 0))
assert np.isclose(v[0], v[-1], atol=1e-9, rtol=0)
checks = [
    f'path_VBM(eV_relative_to_Ef) {v.max():.12g}',
    f'path_CBM(eV_relative_to_Ef) {c.min():.12g}',
    f'path_indirect_gap(eV) {gap:.12g}',
    f'path_min_direct_gap(eV) {direct.min():.12g}',
    f'VBM_path_index(1) {v.argmax()}',
    f'CBM_path_index(1) {c.argmin()}',
    f'DOS_window_integral(states/cell) {np.trapezoid(dos[:, 1], dos[:, 0]):.12g}',
    'full_band_weight(states/cell) 104',
    f'DOS_energy_spacing(eV) {dos[1, 0]-dos[0, 0]:.12g}',
    f'DOS_at_Ef_interpolated(states/eV/cell) {np.interp(0,*dos.T):.12g}',
    f'atom_PDOS_sum_max_error(states/eV/cell) {atom_error:.12g}',
]

for name, filename in [('initial', 'Bulk_MoS2.cif'),
                       ('final', PREFIX + 'GROUND-GPAW-Result-Final.cif')]:
    text = (DATA / filename).read_text()
    lengths = [float(re.search(r'_cell_length_' + a + r'\s+(\S+)', text)[1])
               for a in 'abc']
    checks.append(f'{name}_cell_lengths(angstrom) ' + ' '.join(f'{a:.12g}' for a in lengths))

plt.rcParams.update({'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False})
fig, (ax, dx) = plt.subplots(1, 2, figsize=(9.7, 5.2), sharey=True,
                            gridspec_kw={'width_ratios': [1.65, 1]})
for band in bands[:, 1:].T:
    ax.plot(x, band, color='#176b91', lw=.85)
special = kp[:, 3] != '-'
ticks = x[special]
for tick in ticks:
    ax.axvline(tick, color='.85', lw=.7)
ax.set(xticks=ticks, xticklabels=[r'$\Gamma$', 'M', 'K', r'$\Gamma$'],
       xlim=(0, x[-1]), ylim=(-3, 3), xlabel='Wave-vector path (kz = 0)',
       ylabel=r'$E-E_F$ (eV)', title='Bulk MoS2 | PBE, no dispersion correction')
ax.scatter([x[0], x[c.argmin()]], [v[0], c.min()], color='#b35b29', s=24, zorder=4)
ax.text(.03, .96, f'Sampled indirect gap: {gap:.4f} eV\nMinimum direct gap: {direct.min():.4f} eV',
        transform=ax.transAxes, va='top', fontsize=9,
        bbox={'facecolor': 'white', 'edgecolor': 'none', 'alpha': .9})
dx.plot(dos[:, 1], dos[:, 0], color='#176b91')
visible = abs(dos[:, 0]) <= 3
dx.set(xlabel='DOS (states/eV/cell)', title='Recorded DOS',
       xlim=(0, 1.1 * dos[visible, 1].max()))
for a in (ax, dx):
    a.axhline(0, ls='--', color='.35', lw=.7)
fig.text(.5, .02, 'Demonstration settings; gap on the saved path, not a full-zone convergence result; DOS samples plotted without added smoothing.',
         ha='center', fontsize=8)
fig.tight_layout(rect=(0, .055, 1, 1))
fig.savefig(ROOT / 'mos2-gpaw-reference.png', dpi=180)
plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.6), sharey=True)
visible_peak = 0
for ax, indices, label, color in [(axes[0], [0, 1], '2 Mo atoms', '#176b91'),
                                 (axes[1], [2, 3, 4, 5], '4 S atoms', '#b35b29')]:
    group = atoms[indices, :, 1:].sum(0)
    visible_peak = max(visible_peak, group[visible][:, [0, 1, 5]].max())
    for column, orbital, style in [(0, 's', ':'), (1, 'p', '--'), (5, 'd', '-')]:
        ax.plot(dos[:, 0], group[:, column], color=color, ls=style, label=orbital)
    ax.axvline(0, color='.5', ls=':', lw=.7)
    ax.set(xlim=(-3, 3), xlabel=r'$E-E_F$ (eV)', title=label + ' | sum per cell')
    ax.legend(frameon=False)
axes[0].set_ylabel('Projected states / (eV cell)')
axes[0].set_ylim(0, 1.1 * visible_peak)
fig.text(.5, .02, 'Atomic projector weights are qualitative orbital character, not a complete partition of total DOS; energy sampling remains coarse.',
         ha='center', fontsize=8)
fig.tight_layout(rect=(0, .06, 1, 1))
fig.savefig(ROOT / 'mos2-gpaw-orbitals.png', dpi=180)
plt.close(fig)
(ROOT / 'checks.dat').write_text('# Derived checks for the original spectral/CIF exports.\n' + '\n'.join(checks) + '\n')
print('\n'.join(checks))

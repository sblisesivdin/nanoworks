# Bulk MoS2 without dispersion: recorded example

Source: example-runs-Va5NDWGi/GPAW/mos2-reference, 28 October 2026. Active input and starting CIF match the inspected repository. Nanoworks 27.2.0rc0, GPAW 26.7.0, ASE 3.29.0, eight processes; exact run commit and dataset package release were not recorded.

This is a six-atom bulk crystal with PBE, 400 eV, 6x6x4 sampling, no D3 or SOC. Settings prioritize a short demonstration. Numerical results are not convergence benchmarks. See the website tutorial for commands, interpretation and limitations. The separate D3 preflight failed in MPI_Init, before DFT; no D3 comparison is provided.

All original electronic tables and CIFs are preserved under data/. checks.dat and the PNGs are derived. Optional redraw: with numpy>=2 and matplotlib installed, run python plot_mos2.py in this directory. It checks long/XYYY/State, KPath, DOS/PDOS energy grids, atom/orbital sums and finite/nonnegative values, then writes both figures and checks.dat. It does not run DFT. The original SCF/machine-specific logs and GPW are not bundled.

SHA256SUMS covers distributed files except itself. MIT terms: LICENSE.md.
